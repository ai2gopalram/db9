<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * DollarBets Points & Ranks Settings
 *
 * Provides a simple admin page under the Settings menu where site
 * administrators can configure coin types and rank thresholds for
 * the custom points system. Configurations are stored in WordPress
 * options and used by the fallback points system.
 */

class DollarBets_Points_Settings {

    /**
     * Constructor hooks the settings page into the admin menu.
     */
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
    }

    /**
     * Register the submenu page under Settings.
     */
    public function add_admin_menu() {
        // Register the settings page under the main Settings menu. This makes
        // the Points & Ranks configuration accessible via Settings → DollarBets Points.
        add_options_page(
            'DollarBets Points & Ranks',
            'DollarBets Points',
            'manage_options',
            'dollarbets-points-settings',
            [$this, 'render_settings_page']
        );

        // Additionally, register a top-level menu item so that administrators
        // can find the Points & Ranks settings more easily. This will appear
        // alongside other WordPress menu items with a BetCoins icon. If a
        // top-level menu already exists for the DollarBets plugin, the slug
        // should be unique to avoid conflicts.
        add_menu_page(
            'DollarBets Points & Ranks',
            'BetCoin Points',
            'manage_options',
            'dollarbets-points-settings',
            [$this, 'render_settings_page'],
            'dashicons-tickets',
            56
        );

        // Also add a submenu under the Predictions post type (if it exists) so
        // administrators can access the page from the plugin’s own menu.
        add_submenu_page(
            'edit.php?post_type=prediction',
            'Points & Ranks',
            'Points & Ranks',
            'manage_options',
            'dollarbets-points-settings',
            [$this, 'render_settings_page']
        );
    }

    /**
     * Render the settings form. Handles saving when the form is submitted.
     */
    public function render_settings_page() {
        // Check capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        // Handle form submission
        if (isset($_POST['dollarbets_points_settings_nonce']) && wp_verify_nonce($_POST['dollarbets_points_settings_nonce'], 'dollarbets_save_points_settings')) {
            $coin_types     = isset($_POST['coin_types']) ? sanitize_textarea_field($_POST['coin_types']) : '';
            $rank_thresholds = isset($_POST['rank_thresholds']) ? sanitize_textarea_field($_POST['rank_thresholds']) : '';
            // Update options
            update_option('dollarbets_coin_types', $coin_types);
            // Parse rank thresholds into array for consistent storage
            $thresholds_array = [];
            if (!empty($rank_thresholds)) {
                $parts = explode(',', $rank_thresholds);
                foreach ($parts as $part) {
                    $pair = explode(':', $part);
                    if (count($pair) === 2) {
                        $name = sanitize_text_field(trim($pair[0]));
                        $value = intval(trim($pair[1]));
                        $thresholds_array[$name] = $value;
                    }
                }
            }
            update_option('dollarbets_rank_thresholds', $thresholds_array);
            echo '<div class="notice notice-success"><p>Settings saved successfully.</p></div>';
        }

        // Retrieve current values (display raw values rather than arrays)
        $coin_types_raw     = get_option('dollarbets_coin_types', 'betcoins:BetCoins');
        $rank_thresholds_opt = get_option('dollarbets_rank_thresholds');
        $rank_thresholds_raw = '';
        if (is_array($rank_thresholds_opt) && !empty($rank_thresholds_opt)) {
            $parts = [];
            foreach ($rank_thresholds_opt as $name => $value) {
                $parts[] = $name . ':' . $value;
            }
            $rank_thresholds_raw = implode(',', $parts);
        } elseif (is_string($rank_thresholds_opt)) {
            $rank_thresholds_raw = $rank_thresholds_opt;
        } else {
            // Default
            $rank_thresholds_raw = 'Diamond:10000,Gold:5000,Silver:1000,Bronze:0';
        }
        ?>
        <div class="wrap">
            <h1>DollarBets Points &amp; Ranks Settings</h1>
            <form method="post" action="">
                <?php wp_nonce_field('dollarbets_save_points_settings', 'dollarbets_points_settings_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="coin_types">Coin Types</label></th>
                        <td>
                            <textarea name="coin_types" id="coin_types" rows="3" cols="50" class="regular-text code"><?php echo esc_textarea($coin_types_raw); ?></textarea>
                            <p class="description">Define your custom coin types in the format <code>slug:Label,slug2:Label2</code>. For example: <code>betcoins:BetCoins,gold:Gold Coins</code>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rank_thresholds">Rank Thresholds</label></th>
                        <td>
                            <textarea name="rank_thresholds" id="rank_thresholds" rows="3" cols="50" class="regular-text code"><?php echo esc_textarea($rank_thresholds_raw); ?></textarea>
                            <p class="description">Define rank names and their minimum required point thresholds, separated by commas. The format is <code>Rank:Threshold,Rank2:Threshold2</code>. Higher thresholds should appear first. Example: <code>Diamond:10000,Gold:5000,Silver:1000,Bronze:0</code>.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }
}

// Initialize settings page on admin side
if (is_admin()) {
    new DollarBets_Points_Settings();
}