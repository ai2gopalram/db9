<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * DollarBets Custom Points System
 *
 * This file provides fallback implementations of key GamiPress functions
 * so that the DollarBets platform can operate without requiring the
 * GamiPress plugin. Points are stored in user meta using the same
 * meta key format that GamiPress uses (_gamipress_{type}_points) to
 * ensure compatibility with existing data. Transaction logging is
 * delegated to the existing db_log_transaction helper when available.
 */

// -----------------------------------------------------------------------------
// Point Retrieval
// -----------------------------------------------------------------------------

if (!function_exists('gamipress_get_user_points')) {
    /**
     * Retrieve a user's points for a given point type.
     *
     * @param int    $user_id    The user ID.
     * @param string $point_type The point type (e.g. 'betcoins').
     * @return int               The current point balance.
     */
    function gamipress_get_user_points($user_id, $point_type = 'betcoins') {
        $user_id = absint($user_id);
        $point_type = sanitize_key($point_type);
        $meta_key = '_gamipress_' . $point_type . '_points';
        $points = get_user_meta($user_id, $meta_key, true);
        if ($points === '' || $points === false) {
            $points = 0;
        }
        return intval($points);
    }
}

// -----------------------------------------------------------------------------
// Point Addition
// -----------------------------------------------------------------------------

if (!function_exists('gamipress_add_points')) {
    /**
     * Add points to a user.
     *
     * @param int    $user_id    The user ID.
     * @param int    $amount     The number of points to add.
     * @param string $point_type The point type.
     * @param array  $args       Optional arguments (e.g. reason).
     * @return int               The new point balance.
     */
    function gamipress_add_points($user_id, $amount, $point_type = 'betcoins', $args = array()) {
        $user_id = absint($user_id);
        $amount = intval($amount);
        $point_type = sanitize_key($point_type);
        $current = gamipress_get_user_points($user_id, $point_type);
        $new     = $current + $amount;
        $meta_key = '_gamipress_' . $point_type . '_points';
        update_user_meta($user_id, $meta_key, $new);

        // If a reason was provided, log the transaction when the helper is available
        $reason = '';
        if (!empty($args['reason'])) {
            $reason = sanitize_text_field($args['reason']);
        }
        if (function_exists('db_log_transaction')) {
            // Determine transaction type based on reason
            $type = 'award';
            if ($reason === 'DollarBets winnings') {
                $type = 'win';
            }
            db_log_transaction($user_id, $type, $amount, $reason ?: 'Points added', ['status' => 'completed']);
        }
        return $new;
    }
}

// -----------------------------------------------------------------------------
// Point Deduction
// -----------------------------------------------------------------------------

if (!function_exists('gamipress_deduct_points')) {
    /**
     * Deduct points from a user.
     *
     * @param int    $user_id    The user ID.
     * @param int    $amount     The number of points to deduct.
     * @param string $point_type The point type.
     * @param array  $args       Optional arguments (e.g. reason).
     * @return int               The new point balance.
     */
    function gamipress_deduct_points($user_id, $amount, $point_type = 'betcoins', $args = array()) {
        $user_id = absint($user_id);
        $amount = intval($amount);
        $point_type = sanitize_key($point_type);
        $current = gamipress_get_user_points($user_id, $point_type);
        $new     = max(0, $current - $amount);
        $meta_key = '_gamipress_' . $point_type . '_points';
        update_user_meta($user_id, $meta_key, $new);

        // Log transaction if possible
        $reason = '';
        if (!empty($args['reason'])) {
            $reason = sanitize_text_field($args['reason']);
        }
        if (function_exists('db_log_transaction')) {
            db_log_transaction($user_id, 'deduct', $amount, $reason ?: 'Points deducted', ['status' => 'completed']);
        }
        return $new;
    }
}

// -----------------------------------------------------------------------------
// Aliases for Award/Deduct
// -----------------------------------------------------------------------------

if (!function_exists('gamipress_award_points_to_user')) {
    /**
     * Award points to a user (alias of gamipress_add_points).
     */
    function gamipress_award_points_to_user($user_id, $amount, $point_type = 'betcoins', $args = array()) {
        return gamipress_add_points($user_id, $amount, $point_type, $args);
    }
}

if (!function_exists('gamipress_deduct_points_to_user')) {
    /**
     * Deduct points from a user (alias of gamipress_deduct_points).
     */
    function gamipress_deduct_points_to_user($user_id, $amount, $point_type = 'betcoins', $args = array()) {
        return gamipress_deduct_points($user_id, $amount, $point_type, $args);
    }
}

// -----------------------------------------------------------------------------
// Rank Handling
// -----------------------------------------------------------------------------

if (!function_exists('db_get_user_rank')) {
    /**
     * Determine a user's rank based on their BetCoins balance.
     * Ranks and thresholds can be customized via the
     * 'dollarbets_rank_thresholds' option or by filtering the
     * 'dollarbets_rank_thresholds' filter.
     *
     * @param int $user_id The user ID.
     * @return string The name of the rank the user currently holds.
     */
    function db_get_user_rank($user_id) {
        $user_id = absint($user_id);
        $points = gamipress_get_user_points($user_id, 'betcoins');
        // Default thresholds (highest rank first)
        $default_thresholds = [
            'Diamond' => 10000,
            'Gold'    => 5000,
            'Silver'  => 1000,
            'Bronze'  => 0,
        ];
        // Option-based thresholds
        $saved = get_option('dollarbets_rank_thresholds');
        $thresholds = [];
        if (is_array($saved)) {
            $thresholds = $saved;
        } elseif (is_string($saved) && !empty($saved)) {
            // Attempt to parse JSON or comma-separated string
            $parsed = json_decode($saved, true);
            if (is_array($parsed)) {
                $thresholds = $parsed;
            } else {
                // Parse format: Rank:Threshold,Rank:Threshold
                $parts = explode(',', $saved);
                foreach ($parts as $part) {
                    $pair = explode(':', $part);
                    if (count($pair) === 2) {
                        $rank_name  = trim($pair[0]);
                        $threshold  = intval(trim($pair[1]));
                        $thresholds[$rank_name] = $threshold;
                    }
                }
            }
        }
        if (empty($thresholds)) {
            $thresholds = $default_thresholds;
        }
        // Allow other plugins/themes to modify thresholds
        $thresholds = apply_filters('dollarbets_rank_thresholds', $thresholds);
        // Sort thresholds descending by value to find highest rank first
        arsort($thresholds, SORT_NUMERIC);
        $rank_name = '';
        foreach ($thresholds as $name => $threshold) {
            if ($points >= $threshold) {
                $rank_name = $name;
                break;
            }
        }
        return $rank_name;
    }
}

// -----------------------------------------------------------------------------
// Coin Type Handling
// -----------------------------------------------------------------------------

if (!function_exists('db_get_coin_types')) {
    /**
     * Retrieve available coin types defined in settings.
     * Returns an array of slug => label pairs. If no custom types are
     * defined, a default BetCoins type is returned.
     *
     * @return array
     */
    function db_get_coin_types() {
        $types = get_option('dollarbets_coin_types');
        $coin_types = [];
        if (is_array($types)) {
            $coin_types = $types;
        } elseif (is_string($types) && !empty($types)) {
            // Parse format slug:Label,slug:Label
            $parts = explode(',', $types);
            foreach ($parts as $part) {
                $pair = explode(':', $part);
                if (count($pair) === 2) {
                    $slug  = sanitize_key(trim($pair[0]));
                    $label = sanitize_text_field(trim($pair[1]));
                    $coin_types[$slug] = $label;
                }
            }
        }
        if (empty($coin_types)) {
            $coin_types = ['betcoins' => 'BetCoins'];
        }
        return apply_filters('dollarbets_coin_types', $coin_types);
    }
}