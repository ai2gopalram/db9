<?php
if (!defined('ABSPATH')) exit;

/**
 * Give 1000 BetCoins to new users on registration
 */
add_action('user_register', function($user_id) {
    $existing = get_user_meta($user_id, '_db_betcoins', true);
    if (empty($existing)) {
        update_user_meta($user_id, '_db_betcoins', 1000);
    }
}, 100);

/**
 * Register REST API endpoints
 */
add_action('rest_api_init', function () {
    register_rest_route('dollarbets/v1', '/user-balance', [
        'methods' => 'GET',
        'callback' => 'db_get_user_balance',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    register_rest_route('dollarbets/v1', '/place-bet', [
        'methods' => 'POST',
        'callback' => 'db_place_bet',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    register_rest_route('dollarbets/v1', '/predictions', [
        'methods' => 'GET',
        'callback' => 'db_get_predictions',
        'permission_callback' => fn() => true,
    ]);
});

/**
 * Get current user BetCoins balance
 */
function db_get_user_balance(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $balance = (int) get_user_meta($user_id, '_db_betcoins', true);

    // Initialize with 1000 if missing
   function db_get_user_balance(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $balance = get_user_meta($user_id, '_db_betcoins', true);

    if ($balance === '') {
        $balance = 1000;
        update_user_meta($user_id, '_db_betcoins', $balance);
    }

    return [
        'user_id' => $user_id,
        'balance' => (int) $balance,
    ];
}
/**
 * Place a bet
 */
function db_place_bet(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $body = $req->get_json_params();

    $prediction_id = absint($body['prediction_id'] ?? 0);
    $choice = sanitize_text_field($body['choice'] ?? '');
    $amount = absint($body['amount'] ?? 0);

    if (!$prediction_id || !in_array($choice, ['yes', 'no']) || $amount <= 0) {
        return new WP_Error('invalid_data', 'Invalid prediction ID, choice, or amount', ['status' => 400]);
    }

    $balance = (int) get_user_meta($user_id, '_db_betcoins', true);
    if ($amount > $balance) {
        return new WP_Error('insufficient_balance', 'Not enough BetCoins.', ['status' => 400]);
    }

    // Subtract balance
    update_user_meta($user_id, '_db_betcoins', $balance - $amount);

    // Save history
    $history = get_user_meta($user_id, 'db_bet_history', true);
    if (!is_array($history)) $history = [];
    $history[] = [
        'prediction_id' => $prediction_id,
        'choice' => $choice,
        'amount' => $amount,
        'timestamp' => current_time('mysql'),
    ];
    update_user_meta($user_id, 'db_bet_history', $history);

    return ['success' => true, 'new_balance' => $balance - $amount];
}

/**
 * Get all predictions
 */
function db_get_predictions(WP_REST_Request $req) {
    $query = new WP_Query([
        'post_type' => 'prediction',
        'post_status' => 'publish',
        'posts_per_page' => 20,
    ]);

    $results = [];

    foreach ($query->posts as $post) {
        $votes_yes = 0;
        $votes_no = 0;

        // Calculate from user history
        $users = get_users(['meta_key' => 'db_bet_history']);
        foreach ($users as $user) {
            $history = get_user_meta($user->ID, 'db_bet_history', true);
            if (!is_array($history)) continue;

            foreach ($history as $bet) {
                if ($bet['prediction_id'] == $post->ID) {
                    if ($bet['choice'] == 'yes') {
                        $votes_yes += $bet['amount'];
                    } else {
                        $votes_no += $bet['amount'];
                    }
                }
            }
        }

        $results[] = [
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'votes_yes' => $votes_yes,
            'votes_no' => $votes_no,
        ];
    }

    return rest_ensure_response($results);
}
