
global $wpdb;
$table_name = $wpdb->prefix . 'dollarbets_bets'; // Ensure correct table name for 'bets'

// Fix for the 'user_id' duplicate key issue
$sql = "
CREATE TABLE IF NOT EXISTS $table_name (
    id BIGINT(20) NOT NULL AUTO_INCREMENT,
    prediction_id BIGINT(20) NOT NULL,
    user_id BIGINT(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY prediction_id (prediction_id),
    KEY user_id (user_id) -- Avoid duplicate UNIQUE index on 'user_id'
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;
";
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
dbDelta($sql);
