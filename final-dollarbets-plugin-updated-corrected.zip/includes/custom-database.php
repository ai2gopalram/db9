<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * DollarBets Custom Database Tables
 * 
 * This file handles the creation and management of custom database tables
 * for the DollarBets platform including transactions, user stats, achievements,
 * ranks, and referrals.
 */

// Create all custom tables on plugin activation
function dollarbets_create_custom_tables() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    
    // Transactions table for detailed logging
    $transactions_table = $wpdb->prefix . 'dollarbets_transactions';
    $sql_transactions = "CREATE TABLE IF NOT EXISTS $transactions_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        transaction_type varchar(50) NOT NULL,
        amount int(11) NOT NULL,
        balance_before int(11) NOT NULL,
        balance_after int(11) NOT NULL,
        description text,
        reference_id bigint(20) DEFAULT NULL,
        status varchar(20) DEFAULT 'completed',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY transaction_type (transaction_type),
        KEY created_at (created_at)
    ) $charset_collate;";
    
    // User stats table
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $sql_user_stats = "CREATE TABLE IF NOT EXISTS $user_stats_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL UNIQUE,
        total_bets int(11) DEFAULT 0,
        total_wins int(11) DEFAULT 0,
        total_losses int(11) DEFAULT 0,
        total_earnings int(11) DEFAULT 0,
        win_rate decimal(5,2) DEFAULT 0.00,
        current_streak int(11) DEFAULT 0,
        best_streak int(11) DEFAULT 0,
        rank_name varchar(100) DEFAULT 'Bronze',
        achievements text,
        referral_code varchar(20) UNIQUE,
        referral_earnings int(11) DEFAULT 0,
        referred_by bigint(20) DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY referral_code (referral_code)
    ) $charset_collate;";
    
    // Achievement types table
    $achievement_types_table = $wpdb->prefix . 'dollarbets_achievement_types';
    $sql_achievement_types = "CREATE TABLE IF NOT EXISTS $achievement_types_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        description text,
        icon_url varchar(255),
        requirement_type varchar(50) NOT NULL,
        requirement_value int(11) NOT NULL,
        reward_amount int(11) DEFAULT 0,
        is_active tinyint(1) DEFAULT 1,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY is_active (is_active)
    ) $charset_collate;";
    
    // Rank types table
    $rank_types_table = $wpdb->prefix . 'dollarbets_rank_types';
    $sql_rank_types = "CREATE TABLE IF NOT EXISTS $rank_types_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        description text,
        icon_url varchar(255),
        min_points int(11) NOT NULL,
        color varchar(7) DEFAULT '#000000',
        is_active tinyint(1) DEFAULT 1,
        sort_order int(11) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY min_points (min_points),
        KEY is_active (is_active)
    ) $charset_collate;";
    
    // Packages table
    $packages_table = $wpdb->prefix . 'dollarbets_packages';
    $sql_packages = "CREATE TABLE IF NOT EXISTS $packages_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        description text,
        betcoins_amount int(11) NOT NULL,
        price decimal(10,2) NOT NULL,
        currency varchar(3) DEFAULT 'USD',
        is_active tinyint(1) DEFAULT 1,
        sort_order int(11) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY is_active (is_active)
    ) $charset_collate;";
    
    // Referral settings table
    $referral_settings_table = $wpdb->prefix . 'dollarbets_referral_settings';
    $sql_referral_settings = "CREATE TABLE IF NOT EXISTS $referral_settings_table (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        is_enabled tinyint(1) DEFAULT 0,
        reward_amount int(11) DEFAULT 100,
        reward_type varchar(20) DEFAULT 'signup',
        description text,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_transactions);
    dbDelta($sql_user_stats);
    dbDelta($sql_achievement_types);
    dbDelta($sql_rank_types);
    dbDelta($sql_packages);
    dbDelta($sql_referral_settings);
    
    // Insert default data
    dollarbets_insert_default_data();
}

// Insert default data
function dollarbets_insert_default_data() {
    global $wpdb;
    
    // Default rank types
    $rank_types_table = $wpdb->prefix . 'dollarbets_rank_types';
    $existing_ranks = $wpdb->get_var("SELECT COUNT(*) FROM $rank_types_table");
    
    if ($existing_ranks == 0) {
        $default_ranks = [
            ['name' => 'Bronze', 'description' => 'Starting rank for new players', 'min_points' => 0, 'color' => '#CD7F32', 'sort_order' => 1],
            ['name' => 'Silver', 'description' => 'Intermediate rank for active players', 'min_points' => 1000, 'color' => '#C0C0C0', 'sort_order' => 2],
            ['name' => 'Gold', 'description' => 'Advanced rank for skilled players', 'min_points' => 5000, 'color' => '#FFD700', 'sort_order' => 3],
            ['name' => 'Diamond', 'description' => 'Elite rank for top players', 'min_points' => 10000, 'color' => '#B9F2FF', 'sort_order' => 4],
        ];
        
        foreach ($default_ranks as $rank) {
            $wpdb->insert($rank_types_table, $rank);
        }
    }
    
    // Default achievement types
    $achievement_types_table = $wpdb->prefix . 'dollarbets_achievement_types';
    $existing_achievements = $wpdb->get_var("SELECT COUNT(*) FROM $achievement_types_table");
    
    if ($existing_achievements == 0) {
        $default_achievements = [
            ['name' => 'First Bet', 'description' => 'Place your first bet', 'requirement_type' => 'bets_placed', 'requirement_value' => 1, 'reward_amount' => 50],
            ['name' => 'Lucky Streak', 'description' => 'Win 5 bets in a row', 'requirement_type' => 'win_streak', 'requirement_value' => 5, 'reward_amount' => 200],
            ['name' => 'High Roller', 'description' => 'Place 100 bets', 'requirement_type' => 'bets_placed', 'requirement_value' => 100, 'reward_amount' => 500],
            ['name' => 'Winner', 'description' => 'Win 50 bets', 'requirement_type' => 'wins', 'requirement_value' => 50, 'reward_amount' => 300],
        ];
        
        foreach ($default_achievements as $achievement) {
            $wpdb->insert($achievement_types_table, $achievement);
        }
    }
    
    // Default packages
    $packages_table = $wpdb->prefix . 'dollarbets_packages';
    $existing_packages = $wpdb->get_var("SELECT COUNT(*) FROM $packages_table");
    
    if ($existing_packages == 0) {
        $default_packages = [
            ['name' => 'Starter Pack', 'description' => 'Perfect for beginners', 'betcoins_amount' => 1000, 'price' => 9.99, 'sort_order' => 1],
            ['name' => 'Pro Pack', 'description' => 'For serious players', 'betcoins_amount' => 5000, 'price' => 39.99, 'sort_order' => 2],
            ['name' => 'Elite Pack', 'description' => 'Maximum value pack', 'betcoins_amount' => 15000, 'price' => 99.99, 'sort_order' => 3],
        ];
        
        foreach ($default_packages as $package) {
            $wpdb->insert($packages_table, $package);
        }
    }
    
    // Default referral settings
    $referral_settings_table = $wpdb->prefix . 'dollarbets_referral_settings';
    $existing_settings = $wpdb->get_var("SELECT COUNT(*) FROM $referral_settings_table");
    
    if ($existing_settings == 0) {
        $wpdb->insert($referral_settings_table, [
            'is_enabled' => 0,
            'reward_amount' => 100,
            'reward_type' => 'signup',
            'description' => 'Earn BetCoins for each successful referral'
        ]);
    }
}

// Enhanced transaction logging
function db_log_transaction($user_id, $type, $amount, $description = '', $args = []) {
    global $wpdb;
    
    $user_id = absint($user_id);
    $amount = intval($amount);
    $type = sanitize_text_field($type);
    $description = sanitize_text_field($description);
    
    // Get current balance
    $current_balance = gamipress_get_user_points($user_id, 'betcoins');
    
    // Calculate new balance based on transaction type
    $balance_before = $current_balance;
    $balance_after = $current_balance;
    
    if (in_array($type, ['bet', 'deduct', 'purchase'])) {
        $balance_after = max(0, $current_balance - $amount);
    } elseif (in_array($type, ['win', 'award', 'refund', 'referral'])) {
        $balance_after = $current_balance + $amount;
    }
    
    $transactions_table = $wpdb->prefix . 'dollarbets_transactions';
    
    $data = [
        'user_id' => $user_id,
        'transaction_type' => $type,
        'amount' => $amount,
        'balance_before' => $balance_before,
        'balance_after' => $balance_after,
        'description' => $description,
        'status' => isset($args['status']) ? $args['status'] : 'completed'
    ];
    
    if (isset($args['reference_id'])) {
        $data['reference_id'] = absint($args['reference_id']);
    }
    
    $result = $wpdb->insert($transactions_table, $data);
    
    // Update user stats
    dollarbets_update_user_stats($user_id, $type, $amount);
    
    return $result !== false ? $wpdb->insert_id : false;
}

// Update user statistics
function dollarbets_update_user_stats($user_id, $transaction_type, $amount) {
    global $wpdb;
    
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    // Get or create user stats record
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    if (!$stats) {
        // Create new stats record
        $referral_code = dollarbets_generate_referral_code($user_id);
        $wpdb->insert($user_stats_table, [
            'user_id' => $user_id,
            'referral_code' => $referral_code
        ]);
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $user_stats_table WHERE user_id = %d",
            $user_id
        ));
    }
    
    $updates = [];
    
    switch ($transaction_type) {
        case 'bet':
            $updates['total_bets'] = $stats->total_bets + 1;
            break;
        case 'win':
            $updates['total_wins'] = $stats->total_wins + 1;
            $updates['total_earnings'] = $stats->total_earnings + $amount;
            $updates['current_streak'] = $stats->current_streak + 1;
            $updates['best_streak'] = max($stats->best_streak, $stats->current_streak + 1);
            break;
        case 'loss':
            $updates['total_losses'] = $stats->total_losses + 1;
            $updates['current_streak'] = 0;
            break;
        case 'referral':
            $updates['referral_earnings'] = $stats->referral_earnings + $amount;
            break;
    }
    
    // Calculate win rate
    if (isset($updates['total_wins']) || isset($updates['total_losses'])) {
        $total_wins = isset($updates['total_wins']) ? $updates['total_wins'] : $stats->total_wins;
        $total_losses = isset($updates['total_losses']) ? $updates['total_losses'] : $stats->total_losses;
        $total_completed = $total_wins + $total_losses;
        $updates['win_rate'] = $total_completed > 0 ? round(($total_wins / $total_completed) * 100, 2) : 0;
    }
    
    // Update rank
    $current_points = gamipress_get_user_points($user_id, 'betcoins');
    $new_rank = dollarbets_get_user_rank_from_points($current_points);
    if ($new_rank !== $stats->rank_name) {
        $updates['rank_name'] = $new_rank;
    }
    
    if (!empty($updates)) {
        $wpdb->update($user_stats_table, $updates, ['user_id' => $user_id]);
    }
}

// Generate unique referral code
function dollarbets_generate_referral_code($user_id) {
    global $wpdb;
    
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    do {
        $code = 'DB' . strtoupper(substr(md5($user_id . time() . rand()), 0, 6));
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $user_stats_table WHERE referral_code = %s",
            $code
        ));
    } while ($exists > 0);
    
    return $code;
}

// Get user rank from points
function dollarbets_get_user_rank_from_points($points) {
    global $wpdb;
    
    $rank_types_table = $wpdb->prefix . 'dollarbets_rank_types';
    
    $rank = $wpdb->get_row($wpdb->prepare(
        "SELECT name FROM $rank_types_table 
         WHERE is_active = 1 AND min_points <= %d 
         ORDER BY min_points DESC LIMIT 1",
        $points
    ));
    
    return $rank ? $rank->name : 'Bronze';
}

