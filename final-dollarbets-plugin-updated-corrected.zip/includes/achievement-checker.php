<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Achievement Checker System
 * 
 * This file handles automatic achievement checking and awarding
 * based on user actions and statistics.
 */

// Check achievements when user stats are updated
add_action('dollarbets_user_stats_updated', 'dollarbets_check_achievements', 10, 2);

function dollarbets_check_achievements($user_id, $stat_type) {
    global $wpdb;
    
    $achievement_types_table = $wpdb->prefix . 'dollarbets_achievement_types';
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    // Get user stats
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    if (!$stats) return;
    
    // Get all active achievements
    $achievements = $wpdb->get_results(
        "SELECT * FROM $achievement_types_table WHERE is_active = 1"
    );
    
    // Get user's current achievements
    $user_achievements = json_decode($stats->achievements, true) ?: [];
    
    foreach ($achievements as $achievement) {
        // Skip if user already has this achievement
        if (in_array($achievement->id, $user_achievements)) {
            continue;
        }
        
        $earned = false;
        
        switch ($achievement->requirement_type) {
            case 'bets_placed':
                $earned = $stats->total_bets >= $achievement->requirement_value;
                break;
                
            case 'wins':
                $earned = $stats->total_wins >= $achievement->requirement_value;
                break;
                
            case 'win_streak':
                $earned = $stats->best_streak >= $achievement->requirement_value;
                break;
                
            case 'total_earnings':
                $earned = $stats->total_earnings >= $achievement->requirement_value;
                break;
                
            case 'referrals':
                $referral_count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $user_stats_table WHERE referred_by = %d",
                    $user_id
                ));
                $earned = $referral_count >= $achievement->requirement_value;
                break;
        }
        
        if ($earned) {
            dollarbets_award_achievement($user_id, $achievement);
        }
    }
}

function dollarbets_award_achievement($user_id, $achievement) {
    global $wpdb;
    
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    // Get current achievements
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT achievements FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    $user_achievements = json_decode($stats->achievements, true) ?: [];
    $user_achievements[] = $achievement->id;
    
    // Update user achievements
    $wpdb->update($user_stats_table, [
        'achievements' => json_encode($user_achievements)
    ], ['user_id' => $user_id]);
    
    // Award BetCoins if specified
    if ($achievement->reward_amount > 0) {
        gamipress_add_points($user_id, $achievement->reward_amount, 'betcoins', [
            'reason' => 'Achievement unlocked: ' . $achievement->name
        ]);
    }
    
    // Log achievement
    db_log_transaction($user_id, 'achievement', $achievement->reward_amount, 
        'Achievement unlocked: ' . $achievement->name, [
        'reference_id' => $achievement->id,
        'status' => 'completed'
    ]);
    
    // Trigger achievement notification (can be used by themes/other plugins)
    do_action('dollarbets_achievement_earned', $user_id, $achievement);
}

// Trigger achievement check when stats are updated
function dollarbets_trigger_achievement_check($user_id, $stat_type) {
    do_action('dollarbets_user_stats_updated', $user_id, $stat_type);
}

// Update the user stats function to trigger achievement checks
add_action('init', function() {
    if (!function_exists('dollarbets_update_user_stats_with_achievements')) {
        function dollarbets_update_user_stats_with_achievements($user_id, $transaction_type, $amount) {
            // Call the original function
            dollarbets_update_user_stats($user_id, $transaction_type, $amount);
            
            // Trigger achievement check
            dollarbets_trigger_achievement_check($user_id, $transaction_type);
        }
    }
});

// Add REST endpoint to get user achievements
add_action('rest_api_init', function () {
    register_rest_route('dollarbets/v1', '/user-achievements', [
        'methods' => 'GET',
        'callback' => 'db_get_user_achievements',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);
});

function db_get_user_achievements(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $achievement_types_table = $wpdb->prefix . 'dollarbets_achievement_types';
    
    // Get user stats
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT achievements FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    $user_achievement_ids = json_decode($stats->achievements ?? '[]', true) ?: [];
    
    // Get all achievements
    $all_achievements = $wpdb->get_results(
        "SELECT * FROM $achievement_types_table WHERE is_active = 1 ORDER BY id ASC"
    );
    
    $achievements = [];
    foreach ($all_achievements as $achievement) {
        $earned = in_array($achievement->id, $user_achievement_ids);
        
        $achievements[] = [
            'id' => $achievement->id,
            'name' => $achievement->name,
            'description' => $achievement->description,
            'icon_url' => $achievement->icon_url,
            'requirement_type' => $achievement->requirement_type,
            'requirement_value' => $achievement->requirement_value,
            'reward_amount' => $achievement->reward_amount,
            'earned' => $earned,
            'earned_date' => $earned ? date('Y-m-d H:i:s') : null // You might want to store actual earned dates
        ];
    }
    
    return rest_ensure_response($achievements);
}

