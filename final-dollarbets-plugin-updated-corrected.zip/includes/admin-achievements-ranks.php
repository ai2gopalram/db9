<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Admin interface for managing achievements and ranks
 */

// Achievements management page
function dollarbets_render_achievements_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    // Handle form submissions
    if ($_POST) {
        if (isset($_POST['add_achievement']) && wp_verify_nonce($_POST['_wpnonce'], 'add_achievement')) {
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $icon_url = esc_url_raw($_POST['icon_url']);
            $requirement_type = sanitize_text_field($_POST['requirement_type']);
            $requirement_value = absint($_POST['requirement_value']);
            $reward_amount = absint($_POST['reward_amount']);
            
            $wpdb->insert($wpdb->prefix . 'dollarbets_achievement_types', [
                'name' => $name,
                'description' => $description,
                'icon_url' => $icon_url,
                'requirement_type' => $requirement_type,
                'requirement_value' => $requirement_value,
                'reward_amount' => $reward_amount,
                'is_active' => 1
            ]);
            
            echo '<div class="notice notice-success"><p>Achievement added successfully!</p></div>';
        }
        
        if (isset($_POST['update_achievement']) && wp_verify_nonce($_POST['_wpnonce'], 'update_achievement')) {
            $achievement_id = absint($_POST['achievement_id']);
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $icon_url = esc_url_raw($_POST['icon_url']);
            $requirement_type = sanitize_text_field($_POST['requirement_type']);
            $requirement_value = absint($_POST['requirement_value']);
            $reward_amount = absint($_POST['reward_amount']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            $wpdb->update($wpdb->prefix . 'dollarbets_achievement_types', [
                'name' => $name,
                'description' => $description,
                'icon_url' => $icon_url,
                'requirement_type' => $requirement_type,
                'requirement_value' => $requirement_value,
                'reward_amount' => $reward_amount,
                'is_active' => $is_active
            ], ['id' => $achievement_id]);
            
            echo '<div class="notice notice-success"><p>Achievement updated successfully!</p></div>';
        }
        
        if (isset($_POST['delete_achievement']) && wp_verify_nonce($_POST['_wpnonce'], 'delete_achievement')) {
            $achievement_id = absint($_POST['achievement_id']);
            $wpdb->delete($wpdb->prefix . 'dollarbets_achievement_types', ['id' => $achievement_id]);
            echo '<div class="notice notice-success"><p>Achievement deleted successfully!</p></div>';
        }
    }

    $achievements = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}dollarbets_achievement_types ORDER BY id DESC");

    ?>
    <div class="wrap">
        <h1>Manage Achievements</h1>
        
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
            <!-- Add new achievement form -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Add New Achievement</h2>
                <form method="post">
                    <?php wp_nonce_field('add_achievement'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="name">Achievement Name</label></th>
                            <td><input type="text" name="name" id="name" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="description">Description</label></th>
                            <td><textarea name="description" id="description" class="large-text" rows="3"></textarea></td>
                        </tr>
                        <tr>
                            <th><label for="icon_url">Icon URL</label></th>
                            <td><input type="url" name="icon_url" id="icon_url" class="regular-text" placeholder="https://example.com/icon.png"></td>
                        </tr>
                        <tr>
                            <th><label for="requirement_type">Requirement Type</label></th>
                            <td>
                                <select name="requirement_type" id="requirement_type" required>
                                    <option value="bets_placed">Bets Placed</option>
                                    <option value="wins">Total Wins</option>
                                    <option value="win_streak">Win Streak</option>
                                    <option value="total_earnings">Total Earnings</option>
                                    <option value="referrals">Referrals Made</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="requirement_value">Requirement Value</label></th>
                            <td><input type="number" name="requirement_value" id="requirement_value" min="1" required></td>
                        </tr>
                        <tr>
                            <th><label for="reward_amount">Reward Amount (BetCoins)</label></th>
                            <td><input type="number" name="reward_amount" id="reward_amount" min="0" value="0"></td>
                        </tr>
                    </table>
                    <button type="submit" name="add_achievement" class="button button-primary">Add Achievement</button>
                </form>
            </div>

            <!-- Existing achievements -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Existing Achievements</h2>
                <?php foreach ($achievements as $achievement): ?>
                <div style="border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 6px; <?php echo $achievement->is_active ? '' : 'opacity: 0.6;'; ?>">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                        <?php if ($achievement->icon_url): ?>
                        <img src="<?php echo esc_url($achievement->icon_url); ?>" alt="Achievement Icon" style="width: 40px; height: 40px; border-radius: 50%;">
                        <?php else: ?>
                        <div style="width: 40px; height: 40px; background: #3b82f6; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            🏆
                        </div>
                        <?php endif; ?>
                        <div>
                            <h3 style="margin: 0; font-size: 16px;"><?php echo esc_html($achievement->name); ?></h3>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php echo esc_html($achievement->description); ?></p>
                        </div>
                        <?php if (!$achievement->is_active): ?>
                        <span style="background: #dc2626; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">INACTIVE</span>
                        <?php endif; ?>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 4px; margin-bottom: 10px;">
                        <strong>Requirement:</strong> <?php echo ucwords(str_replace('_', ' ', $achievement->requirement_type)); ?> - <?php echo $achievement->requirement_value; ?><br>
                        <strong>Reward:</strong> <?php echo number_format($achievement->reward_amount); ?> BetCoins
                    </div>
                    
                    <form method="post" style="display: inline-block;">
                        <?php wp_nonce_field('update_achievement'); ?>
                        <input type="hidden" name="achievement_id" value="<?php echo $achievement->id; ?>">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Name:</label>
                                <input type="text" name="name" value="<?php echo esc_attr($achievement->name); ?>" class="regular-text" required>
                            </div>
                            <div>
                                <label>Icon URL:</label>
                                <input type="url" name="icon_url" value="<?php echo esc_attr($achievement->icon_url); ?>" class="regular-text">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 10px;">
                            <label>Description:</label>
                            <textarea name="description" class="large-text" rows="2"><?php echo esc_textarea($achievement->description); ?></textarea>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Requirement Type:</label>
                                <select name="requirement_type">
                                    <option value="bets_placed" <?php selected($achievement->requirement_type, 'bets_placed'); ?>>Bets Placed</option>
                                    <option value="wins" <?php selected($achievement->requirement_type, 'wins'); ?>>Total Wins</option>
                                    <option value="win_streak" <?php selected($achievement->requirement_type, 'win_streak'); ?>>Win Streak</option>
                                    <option value="total_earnings" <?php selected($achievement->requirement_type, 'total_earnings'); ?>>Total Earnings</option>
                                    <option value="referrals" <?php selected($achievement->requirement_type, 'referrals'); ?>>Referrals Made</option>
                                </select>
                            </div>
                            <div>
                                <label>Requirement Value:</label>
                                <input type="number" name="requirement_value" value="<?php echo $achievement->requirement_value; ?>" min="1" required>
                            </div>
                            <div>
                                <label>Reward Amount:</label>
                                <input type="number" name="reward_amount" value="<?php echo $achievement->reward_amount; ?>" min="0">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 10px;">
                            <label>
                                <input type="checkbox" name="is_active" <?php checked($achievement->is_active, 1); ?>>
                                Active
                            </label>
                        </div>
                        
                        <button type="submit" name="update_achievement" class="button button-primary">Update</button>
                    </form>
                    
                    <form method="post" style="display: inline-block; margin-left: 10px;" onsubmit="return confirm('Are you sure you want to delete this achievement?');">
                        <?php wp_nonce_field('delete_achievement'); ?>
                        <input type="hidden" name="achievement_id" value="<?php echo $achievement->id; ?>">
                        <button type="submit" name="delete_achievement" class="button button-secondary">Delete</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
}

// Ranks management page
function dollarbets_render_ranks_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    // Handle form submissions
    if ($_POST) {
        if (isset($_POST['add_rank']) && wp_verify_nonce($_POST['_wpnonce'], 'add_rank')) {
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $icon_url = esc_url_raw($_POST['icon_url']);
            $min_points = absint($_POST['min_points']);
            $color = sanitize_hex_color($_POST['color']);
            $sort_order = absint($_POST['sort_order']);
            
            $wpdb->insert($wpdb->prefix . 'dollarbets_rank_types', [
                'name' => $name,
                'description' => $description,
                'icon_url' => $icon_url,
                'min_points' => $min_points,
                'color' => $color,
                'sort_order' => $sort_order,
                'is_active' => 1
            ]);
            
            echo '<div class="notice notice-success"><p>Rank added successfully!</p></div>';
        }
        
        if (isset($_POST['update_rank']) && wp_verify_nonce($_POST['_wpnonce'], 'update_rank')) {
            $rank_id = absint($_POST['rank_id']);
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $icon_url = esc_url_raw($_POST['icon_url']);
            $min_points = absint($_POST['min_points']);
            $color = sanitize_hex_color($_POST['color']);
            $sort_order = absint($_POST['sort_order']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            $wpdb->update($wpdb->prefix . 'dollarbets_rank_types', [
                'name' => $name,
                'description' => $description,
                'icon_url' => $icon_url,
                'min_points' => $min_points,
                'color' => $color,
                'sort_order' => $sort_order,
                'is_active' => $is_active
            ], ['id' => $rank_id]);
            
            echo '<div class="notice notice-success"><p>Rank updated successfully!</p></div>';
        }
        
        if (isset($_POST['delete_rank']) && wp_verify_nonce($_POST['_wpnonce'], 'delete_rank')) {
            $rank_id = absint($_POST['rank_id']);
            $wpdb->delete($wpdb->prefix . 'dollarbets_rank_types', ['id' => $rank_id]);
            echo '<div class="notice notice-success"><p>Rank deleted successfully!</p></div>';
        }
    }

    $ranks = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}dollarbets_rank_types ORDER BY sort_order ASC");

    ?>
    <div class="wrap">
        <h1>Manage Ranks</h1>
        
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">
            <!-- Add new rank form -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Add New Rank</h2>
                <form method="post">
                    <?php wp_nonce_field('add_rank'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="name">Rank Name</label></th>
                            <td><input type="text" name="name" id="name" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="description">Description</label></th>
                            <td><textarea name="description" id="description" class="large-text" rows="3"></textarea></td>
                        </tr>
                        <tr>
                            <th><label for="icon_url">Icon URL</label></th>
                            <td><input type="url" name="icon_url" id="icon_url" class="regular-text" placeholder="https://example.com/icon.png"></td>
                        </tr>
                        <tr>
                            <th><label for="min_points">Minimum Points Required</label></th>
                            <td><input type="number" name="min_points" id="min_points" min="0" required></td>
                        </tr>
                        <tr>
                            <th><label for="color">Rank Color</label></th>
                            <td><input type="color" name="color" id="color" value="#3b82f6"></td>
                        </tr>
                        <tr>
                            <th><label for="sort_order">Sort Order</label></th>
                            <td><input type="number" name="sort_order" id="sort_order" min="0" value="0"></td>
                        </tr>
                    </table>
                    <button type="submit" name="add_rank" class="button button-primary">Add Rank</button>
                </form>
            </div>

            <!-- Existing ranks -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Existing Ranks</h2>
                <?php foreach ($ranks as $rank): ?>
                <div style="border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 6px; <?php echo $rank->is_active ? '' : 'opacity: 0.6;'; ?>">
                    <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                        <?php if ($rank->icon_url): ?>
                        <img src="<?php echo esc_url($rank->icon_url); ?>" alt="Rank Icon" style="width: 40px; height: 40px; border-radius: 50%;">
                        <?php else: ?>
                        <div style="width: 40px; height: 40px; background: <?php echo esc_attr($rank->color); ?>; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <?php echo strtoupper(substr($rank->name, 0, 1)); ?>
                        </div>
                        <?php endif; ?>
                        <div>
                            <h3 style="margin: 0; font-size: 16px; color: <?php echo esc_attr($rank->color); ?>;"><?php echo esc_html($rank->name); ?></h3>
                            <p style="margin: 0; color: #666; font-size: 14px;"><?php echo esc_html($rank->description); ?></p>
                        </div>
                        <?php if (!$rank->is_active): ?>
                        <span style="background: #dc2626; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">INACTIVE</span>
                        <?php endif; ?>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 10px; border-radius: 4px; margin-bottom: 10px;">
                        <strong>Minimum Points:</strong> <?php echo number_format($rank->min_points); ?> BetCoins<br>
                        <strong>Sort Order:</strong> <?php echo $rank->sort_order; ?>
                    </div>
                    
                    <form method="post" style="display: inline-block;">
                        <?php wp_nonce_field('update_rank'); ?>
                        <input type="hidden" name="rank_id" value="<?php echo $rank->id; ?>">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Name:</label>
                                <input type="text" name="name" value="<?php echo esc_attr($rank->name); ?>" class="regular-text" required>
                            </div>
                            <div>
                                <label>Icon URL:</label>
                                <input type="url" name="icon_url" value="<?php echo esc_attr($rank->icon_url); ?>" class="regular-text">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 10px;">
                            <label>Description:</label>
                            <textarea name="description" class="large-text" rows="2"><?php echo esc_textarea($rank->description); ?></textarea>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Minimum Points:</label>
                                <input type="number" name="min_points" value="<?php echo $rank->min_points; ?>" min="0" required>
                            </div>
                            <div>
                                <label>Color:</label>
                                <input type="color" name="color" value="<?php echo esc_attr($rank->color); ?>">
                            </div>
                            <div>
                                <label>Sort Order:</label>
                                <input type="number" name="sort_order" value="<?php echo $rank->sort_order; ?>" min="0">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 10px;">
                            <label>
                                <input type="checkbox" name="is_active" <?php checked($rank->is_active, 1); ?>>
                                Active
                            </label>
                        </div>
                        
                        <button type="submit" name="update_rank" class="button button-primary">Update</button>
                    </form>
                    
                    <form method="post" style="display: inline-block; margin-left: 10px;" onsubmit="return confirm('Are you sure you want to delete this rank?');">
                        <?php wp_nonce_field('delete_rank'); ?>
                        <input type="hidden" name="rank_id" value="<?php echo $rank->id; ?>">
                        <button type="submit" name="delete_rank" class="button button-secondary">Delete</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
}

// Referral settings page
function dollarbets_render_referrals_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    // Handle form submissions
    if ($_POST && wp_verify_nonce($_POST['_wpnonce'], 'update_referral_settings')) {
        $is_enabled = isset($_POST['is_enabled']) ? 1 : 0;
        $reward_amount = absint($_POST['reward_amount']);
        $reward_type = sanitize_text_field($_POST['reward_type']);
        $description = sanitize_textarea_field($_POST['description']);
        
        $wpdb->query($wpdb->prepare("
            UPDATE {$wpdb->prefix}dollarbets_referral_settings 
            SET is_enabled = %d, reward_amount = %d, reward_type = %s, description = %s
            WHERE id = 1
        ", $is_enabled, $reward_amount, $reward_type, $description));
        
        echo '<div class="notice notice-success"><p>Referral settings updated successfully!</p></div>';
    }

    $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
    if (!$settings) {
        // Create default settings if none exist
        $wpdb->insert($wpdb->prefix . 'dollarbets_referral_settings', [
            'is_enabled' => 0,
            'reward_amount' => 100,
            'reward_type' => 'signup',
            'description' => 'Earn BetCoins for each successful referral'
        ]);
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
    }

    // Get referral statistics
    $total_referrals = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}dollarbets_user_stats WHERE referred_by IS NOT NULL");
    $total_referral_earnings = $wpdb->get_var("SELECT SUM(referral_earnings) FROM {$wpdb->prefix}dollarbets_user_stats");

    ?>
    <div class="wrap">
        <h1>Referral Settings</h1>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Settings form -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Referral Configuration</h2>
                <form method="post">
                    <?php wp_nonce_field('update_referral_settings'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="is_enabled">Enable Referral System</label></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="is_enabled" id="is_enabled" <?php checked($settings->is_enabled, 1); ?>>
                                    Enable referral rewards
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="reward_amount">Reward Amount</label></th>
                            <td>
                                <input type="number" name="reward_amount" id="reward_amount" value="<?php echo $settings->reward_amount; ?>" min="0" required>
                                <p class="description">BetCoins awarded for each successful referral</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="reward_type">Reward Type</label></th>
                            <td>
                                <select name="reward_type" id="reward_type">
                                    <option value="signup" <?php selected($settings->reward_type, 'signup'); ?>>On Signup</option>
                                    <option value="first_bet" <?php selected($settings->reward_type, 'first_bet'); ?>>On First Bet</option>
                                    <option value="first_purchase" <?php selected($settings->reward_type, 'first_purchase'); ?>>On First Purchase</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="description">Description</label></th>
                            <td>
                                <textarea name="description" id="description" class="large-text" rows="3"><?php echo esc_textarea($settings->description); ?></textarea>
                                <p class="description">This text will be shown to users in their profile</p>
                            </td>
                        </tr>
                    </table>
                    <button type="submit" class="button button-primary">Update Settings</button>
                </form>
            </div>

            <!-- Statistics -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Referral Statistics</h2>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                    <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 6px;">
                        <h3 style="margin: 0 0 5px 0; color: #3b82f6;">Total Referrals</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_referrals); ?></p>
                    </div>
                    <div style="text-align: center; padding: 15px; background: #f8f9fa; border-radius: 6px;">
                        <h3 style="margin: 0 0 5px 0; color: #10b981;">Total Earnings</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_referral_earnings); ?> BC</p>
                    </div>
                </div>

                <h3>Top Referrers</h3>
                <?php
                $top_referrers = $wpdb->get_results("
                    SELECT u.display_name, us.referral_earnings, us.referral_code,
                           (SELECT COUNT(*) FROM {$wpdb->prefix}dollarbets_user_stats us2 WHERE us2.referred_by = u.ID) as referral_count
                    FROM {$wpdb->users} u
                    LEFT JOIN {$wpdb->prefix}dollarbets_user_stats us ON u.ID = us.user_id
                    WHERE us.referral_earnings > 0
                    ORDER BY us.referral_earnings DESC
                    LIMIT 10
                ");
                ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Referral Code</th>
                            <th>Referrals</th>
                            <th>Earnings</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($top_referrers as $referrer): ?>
                        <tr>
                            <td><?php echo esc_html($referrer->display_name); ?></td>
                            <td><code><?php echo esc_html($referrer->referral_code); ?></code></td>
                            <td><?php echo number_format($referrer->referral_count); ?></td>
                            <td><?php echo number_format($referrer->referral_earnings); ?> BC</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

