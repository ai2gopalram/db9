<?php
if (!defined('ABSPATH')) exit;

/**
 * Enhanced REST API for DollarBets Platform
 * 
 * This file provides improved REST API endpoints with proper balance handling,
 * pagination, betting restrictions, and comprehensive data management.
 */

/**
 * Give 1000 BetCoins to new users on registration
 */
add_action('user_register', function($user_id) {
    // Use the custom points system
    $existing = gamipress_get_user_points($user_id, 'betcoins');
    if ($existing == 0) {
        gamipress_add_points($user_id, 1000, 'betcoins', ['reason' => 'Welcome bonus']);
    }
}, 100);

/**
 * Register enhanced REST API endpoints
 */
add_action('rest_api_init', function () {
    // User balance endpoint
    register_rest_route('dollarbets/v1', '/user-balance', [
        'methods' => 'GET',
        'callback' => 'db_get_user_balance_enhanced',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Place bet endpoint
    register_rest_route('dollarbets/v1', '/place-bet', [
        'methods' => 'POST',
        'callback' => 'db_place_bet_enhanced',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Predictions with pagination
    register_rest_route('dollarbets/v1', '/predictions', [
        'methods' => 'GET',
        'callback' => 'db_get_predictions_enhanced',
        'permission_callback' => fn() => true,
    ]);

    // User stats endpoint
    register_rest_route('dollarbets/v1', '/user-stats', [
        'methods' => 'GET',
        'callback' => 'db_get_user_stats',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Packages endpoint
    register_rest_route('dollarbets/v1', '/packages', [
        'methods' => 'GET',
        'callback' => 'db_get_packages',
        'permission_callback' => fn() => true,
    ]);

    // Transaction history endpoint
    register_rest_route('dollarbets/v1', '/transactions', [
        'methods' => 'GET',
        'callback' => 'db_get_user_transactions',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Check if user already bet on prediction
    register_rest_route('dollarbets/v1', '/check-bet/(?P<prediction_id>\d+)', [
        'methods' => 'GET',
        'callback' => 'db_check_user_bet',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);
});

/**
 * Get current user BetCoins balance with additional info
 */
function db_get_user_balance_enhanced(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $balance = gamipress_get_user_points($user_id, 'betcoins');

    // Initialize with 1000 if missing
    if ($balance == 0) {
        $balance = 1000;
        gamipress_add_points($user_id, $balance, 'betcoins', ['reason' => 'Initial balance']);
    }

    // Get user stats
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));

    $rank = $stats ? $stats->rank_name : dollarbets_get_user_rank_from_points($balance);

    return [
        'user_id' => $user_id,
        'balance' => $balance,
        'rank' => $rank,
        'formatted_balance' => number_format($balance),
    ];
}

/**
 * Enhanced place bet function with restrictions and proper logging
 */
function db_place_bet_enhanced(WP_REST_Request $req) {
    $user_id = get_current_user_id();
    $body = $req->get_json_params();

    $prediction_id = absint($body['prediction_id'] ?? 0);
    $choice = sanitize_text_field($body['choice'] ?? '');
    $amount = absint($body['amount'] ?? 0);

    if (!$prediction_id || !in_array($choice, ['yes', 'no']) || $amount <= 0) {
        return new WP_Error('invalid_data', 'Invalid prediction ID, choice, or amount', ['status' => 400]);
    }

    // Check if prediction exists and is active
    $prediction = get_post($prediction_id);
    if (!$prediction || $prediction->post_type !== 'prediction') {
        return new WP_Error('invalid_prediction', 'Prediction not found', ['status' => 404]);
    }

    // Check if prediction is expired
    $expiry_date = get_post_meta($prediction_id, 'prediction_expiry', true);
    if ($expiry_date && strtotime($expiry_date) < time()) {
        return new WP_Error('prediction_expired', 'Betting Closed - Prediction has expired', ['status' => 400]);
    }

    // Check if user already bet on this prediction
    global $wpdb;
    $bets_table = $wpdb->prefix . 'dollarbets_bets';
    $existing_bet = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $bets_table WHERE user_id = %d AND prediction_id = %d",
        $user_id, $prediction_id
    ));

    if ($existing_bet > 0) {
        return new WP_Error('already_bet', 'You have already placed a bet on this prediction', ['status' => 400]);
    }

    $balance = gamipress_get_user_points($user_id, 'betcoins');
    if ($amount > $balance) {
        return new WP_Error('insufficient_balance', 'Not enough BetCoins.', ['status' => 400]);
    }

    // Deduct balance
    gamipress_deduct_points($user_id, $amount, 'betcoins', ['reason' => 'Bet placed on prediction #' . $prediction_id]);

    // Record bet in database
    $bet_result = $wpdb->insert($bets_table, [
        'user_id' => $user_id,
        'prediction_id' => $prediction_id,
        'bet_type' => $choice,
        'amount' => $amount,
        'created_at' => current_time('mysql')
    ]);

    if ($bet_result === false) {
        // Refund if bet recording failed
        gamipress_add_points($user_id, $amount, 'betcoins', ['reason' => 'Bet refund - recording failed']);
        return new WP_Error('bet_failed', 'Failed to record bet', ['status' => 500]);
    }

    // Update prediction totals
    $predictions_table = $wpdb->prefix . 'dollarbets_predictions';
    $prediction_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $predictions_table WHERE post_id = %d",
        $prediction_id
    ));

    if (!$prediction_data) {
        // Create prediction record
        $wpdb->insert($predictions_table, [
            'post_id' => $prediction_id,
            'total_bets_yes' => $choice === 'yes' ? $amount : 0,
            'total_bets_no' => $choice === 'no' ? $amount : 0,
        ]);
    } else {
        // Update existing record
        $update_field = $choice === 'yes' ? 'total_bets_yes' : 'total_bets_no';
        $wpdb->query($wpdb->prepare(
            "UPDATE $predictions_table SET $update_field = $update_field + %d WHERE post_id = %d",
            $amount, $prediction_id
        ));
    }

    // Log transaction
    db_log_transaction($user_id, 'bet', $amount, 'Bet placed on prediction: ' . $prediction->post_title, [
        'reference_id' => $prediction_id,
        'status' => 'completed'
    ]);

    // Trigger first bet action if applicable
    if (function_exists('dollarbets_trigger_first_bet')) {
        dollarbets_trigger_first_bet($user_id);
    }

    $new_balance = gamipress_get_user_points($user_id, 'betcoins');

    return [
        'success' => true,
        'new_balance' => $new_balance,
        'formatted_balance' => number_format($new_balance),
        'bet_id' => $wpdb->insert_id
    ];
}

/**
 * Get predictions with pagination and real vote counts
 */
function db_get_predictions_enhanced(WP_REST_Request $req) {
    $page = absint($req->get_param('page') ?: 1);
    $per_page = 24; // Fixed at 24 per page as requested
    $offset = ($page - 1) * $per_page;

    $query = new WP_Query([
        'post_type' => 'prediction',
        'post_status' => 'publish',
        'posts_per_page' => $per_page,
        'offset' => $offset,
        'orderby' => 'date',
        'order' => 'DESC',
    ]);

    global $wpdb;
    $predictions_table = $wpdb->prefix . 'dollarbets_predictions';
    $bets_table = $wpdb->prefix . 'dollarbets_bets';

    $results = [];
    $current_user_id = get_current_user_id();

    foreach ($query->posts as $post) {
        // Get real vote counts from database
        $prediction_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $predictions_table WHERE post_id = %d",
            $post->ID
        ));

        $votes_yes = $prediction_data ? $prediction_data->total_bets_yes : 0;
        $votes_no = $prediction_data ? $prediction_data->total_bets_no : 0;
        $total_votes = $votes_yes + $votes_no;

        // Calculate real percentages
        $percentage_yes = $total_votes > 0 ? round(($votes_yes / $total_votes) * 100, 1) : 50;
        $percentage_no = $total_votes > 0 ? round(($votes_no / $total_votes) * 100, 1) : 50;

        // Check if current user has bet on this prediction
        $user_bet = null;
        if ($current_user_id) {
            $user_bet = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $bets_table WHERE user_id = %d AND prediction_id = %d",
                $current_user_id, $post->ID
            ));
        }

        // Check if prediction is expired
        $expiry_date = get_post_meta($post->ID, 'prediction_expiry', true);
        $is_expired = $expiry_date && strtotime($expiry_date) < time();

        // Get featured image
        $featured_image = get_the_post_thumbnail_url($post->ID, 'medium');

        $results[] = [
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => wp_trim_words($post->post_content, 30),
            'featured_image' => $featured_image,
            'votes_yes' => $votes_yes,
            'votes_no' => $votes_no,
            'total_votes' => $total_votes,
            'percentage_yes' => $percentage_yes,
            'percentage_no' => $percentage_no,
            'user_bet' => $user_bet ? [
                'choice' => $user_bet->bet_type,
                'amount' => $user_bet->amount
            ] : null,
            'is_expired' => $is_expired,
            'expiry_date' => $expiry_date,
            'status' => $is_expired ? 'expired' : 'active'
        ];
    }

    // Get total count for pagination
    $total_query = new WP_Query([
        'post_type' => 'prediction',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'fields' => 'ids',
    ]);

    $total_predictions = $total_query->found_posts;
    $total_pages = ceil($total_predictions / $per_page);

    return rest_ensure_response([
        'predictions' => $results,
        'pagination' => [
            'current_page' => $page,
            'per_page' => $per_page,
            'total_predictions' => $total_predictions,
            'total_pages' => $total_pages,
            'has_more' => $page < $total_pages
        ]
    ]);
}

/**
 * Get user statistics
 */
function db_get_user_stats(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));

    if (!$stats) {
        return [
            'total_bets' => 0,
            'total_wins' => 0,
            'total_losses' => 0,
            'win_rate' => 0,
            'current_streak' => 0,
            'best_streak' => 0,
            'rank_name' => 'Bronze',
            'referral_code' => '',
            'referral_earnings' => 0
        ];
    }

    return [
        'total_bets' => $stats->total_bets,
        'total_wins' => $stats->total_wins,
        'total_losses' => $stats->total_losses,
        'win_rate' => $stats->win_rate,
        'current_streak' => $stats->current_streak,
        'best_streak' => $stats->best_streak,
        'rank_name' => $stats->rank_name,
        'referral_code' => $stats->referral_code,
        'referral_earnings' => $stats->referral_earnings
    ];
}

/**
 * Get available packages
 */
function db_get_packages(WP_REST_Request $request) {
    global $wpdb;
    $packages_table = $wpdb->prefix . 'dollarbets_packages';
    
    $packages = $wpdb->get_results(
        "SELECT * FROM $packages_table WHERE is_active = 1 ORDER BY sort_order ASC"
    );

    $result = [];
    foreach ($packages as $package) {
        $result[] = [
            'id' => $package->id,
            'name' => $package->name,
            'description' => $package->description,
            'betcoins_amount' => $package->betcoins_amount,
            'price' => $package->price,
            'currency' => $package->currency,
            'formatted_price' => '$' . number_format($package->price, 2)
        ];
    }

    return rest_ensure_response($result);
}

/**
 * Get user transaction history
 */
function db_get_user_transactions(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $page = absint($request->get_param('page') ?: 1);
    $per_page = 20;
    $offset = ($page - 1) * $per_page;

    global $wpdb;
    $transactions_table = $wpdb->prefix . 'dollarbets_transactions';
    
    $transactions = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $transactions_table 
         WHERE user_id = %d 
         ORDER BY created_at DESC 
         LIMIT %d OFFSET %d",
        $user_id, $per_page, $offset
    ));

    $result = [];
    foreach ($transactions as $transaction) {
        $result[] = [
            'id' => $transaction->id,
            'type' => $transaction->transaction_type,
            'amount' => $transaction->amount,
            'balance_before' => $transaction->balance_before,
            'balance_after' => $transaction->balance_after,
            'description' => $transaction->description,
            'status' => $transaction->status,
            'created_at' => $transaction->created_at,
            'formatted_amount' => number_format($transaction->amount),
            'formatted_date' => date('M j, Y g:i A', strtotime($transaction->created_at))
        ];
    }

    return rest_ensure_response($result);
}

/**
 * Check if user has already bet on a prediction
 */
function db_check_user_bet(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $prediction_id = absint($request->get_param('prediction_id'));

    global $wpdb;
    $bets_table = $wpdb->prefix . 'dollarbets_bets';
    
    $bet = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $bets_table WHERE user_id = %d AND prediction_id = %d",
        $user_id, $prediction_id
    ));

    return [
        'has_bet' => $bet !== null,
        'bet_details' => $bet ? [
            'choice' => $bet->bet_type,
            'amount' => $bet->amount,
            'created_at' => $bet->created_at
        ] : null
    ];
}

