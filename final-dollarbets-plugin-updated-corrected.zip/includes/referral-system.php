<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Referral System for DollarBets Platform
 * 
 * This file handles the referral system including code generation,
 * tracking, rewards, and user profile integration.
 */

// Add referral endpoints to REST API
add_action('rest_api_init', function () {
    // Get referral info
    register_rest_route('dollarbets/v1', '/referral-info', [
        'methods' => 'GET',
        'callback' => 'db_get_referral_info',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Apply referral code
    register_rest_route('dollarbets/v1', '/apply-referral', [
        'methods' => 'POST',
        'callback' => 'db_apply_referral_code',
        'permission_callback' => fn() => is_user_logged_in(),
    ]);

    // Get referral settings (public)
    register_rest_route('dollarbets/v1', '/referral-settings', [
        'methods' => 'GET',
        'callback' => 'db_get_referral_settings',
        'permission_callback' => fn() => true,
    ]);
});

/**
 * Get user's referral information
 */
function db_get_referral_info(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $referral_settings_table = $wpdb->prefix . 'dollarbets_referral_settings';
    
    // Get user stats
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    // Get referral settings
    $settings = $wpdb->get_row("SELECT * FROM $referral_settings_table WHERE id = 1");
    
    if (!$stats) {
        // Create user stats if they don't exist
        $referral_code = dollarbets_generate_referral_code($user_id);
        $wpdb->insert($user_stats_table, [
            'user_id' => $user_id,
            'referral_code' => $referral_code
        ]);
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $user_stats_table WHERE user_id = %d",
            $user_id
        ));
    }
    
    // Get referral count
    $referral_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $user_stats_table WHERE referred_by = %d",
        $user_id
    ));
    
    // Get referred by user info
    $referred_by_user = null;
    if ($stats->referred_by) {
        $referred_by = get_user_by('ID', $stats->referred_by);
        if ($referred_by) {
            $referred_by_user = [
                'id' => $referred_by->ID,
                'name' => $referred_by->display_name
            ];
        }
    }
    
    return [
        'referral_code' => $stats->referral_code,
        'referral_earnings' => $stats->referral_earnings,
        'referral_count' => $referral_count,
        'referred_by' => $referred_by_user,
        'is_enabled' => $settings ? $settings->is_enabled : 0,
        'reward_amount' => $settings ? $settings->reward_amount : 0,
        'description' => $settings ? $settings->description : '',
        'referral_url' => home_url('?ref=' . $stats->referral_code)
    ];
}

/**
 * Apply referral code for current user
 */
function db_apply_referral_code(WP_REST_Request $request) {
    $user_id = get_current_user_id();
    $body = $request->get_json_params();
    $referral_code = sanitize_text_field($body['referral_code'] ?? '');
    
    if (empty($referral_code)) {
        return new WP_Error('invalid_code', 'Please enter a referral code', ['status' => 400]);
    }
    
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    // Check if user already has a referrer
    $current_stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    if ($current_stats && $current_stats->referred_by) {
        return new WP_Error('already_referred', 'You have already been referred by another user', ['status' => 400]);
    }
    
    // Find the referrer
    $referrer_stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE referral_code = %s",
        $referral_code
    ));
    
    if (!$referrer_stats) {
        return new WP_Error('invalid_code', 'Invalid referral code', ['status' => 400]);
    }
    
    // Can't refer yourself
    if ($referrer_stats->user_id == $user_id) {
        return new WP_Error('self_referral', 'You cannot refer yourself', ['status' => 400]);
    }
    
    // Check if referral system is enabled
    $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
    if (!$settings || !$settings->is_enabled) {
        return new WP_Error('referral_disabled', 'Referral system is currently disabled', ['status' => 400]);
    }
    
    // Update user's referrer
    if ($current_stats) {
        $wpdb->update($user_stats_table, [
            'referred_by' => $referrer_stats->user_id
        ], ['user_id' => $user_id]);
    } else {
        // Create new stats record
        $user_referral_code = dollarbets_generate_referral_code($user_id);
        $wpdb->insert($user_stats_table, [
            'user_id' => $user_id,
            'referred_by' => $referrer_stats->user_id,
            'referral_code' => $user_referral_code
        ]);
    }
    
    // Award referral bonus based on settings
    if ($settings->reward_type === 'signup') {
        dollarbets_award_referral_bonus($referrer_stats->user_id, $settings->reward_amount);
    }
    
    $referrer = get_user_by('ID', $referrer_stats->user_id);
    
    return [
        'success' => true,
        'message' => 'Referral code applied successfully!',
        'referrer_name' => $referrer ? $referrer->display_name : 'Unknown'
    ];
}

/**
 * Get referral settings (public endpoint)
 */
function db_get_referral_settings(WP_REST_Request $request) {
    global $wpdb;
    $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
    
    if (!$settings) {
        return [
            'is_enabled' => false,
            'reward_amount' => 0,
            'description' => ''
        ];
    }
    
    return [
        'is_enabled' => (bool) $settings->is_enabled,
        'reward_amount' => $settings->reward_amount,
        'description' => $settings->description,
        'reward_type' => $settings->reward_type
    ];
}

/**
 * Award referral bonus
 */
function dollarbets_award_referral_bonus($referrer_id, $amount) {
    global $wpdb;
    
    // Award BetCoins
    gamipress_add_points($referrer_id, $amount, 'betcoins', [
        'reason' => 'Referral bonus'
    ]);
    
    // Update referral earnings
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $wpdb->query($wpdb->prepare(
        "UPDATE $user_stats_table SET referral_earnings = referral_earnings + %d WHERE user_id = %d",
        $amount, $referrer_id
    ));
    
    // Log transaction
    db_log_transaction($referrer_id, 'referral', $amount, 'Referral bonus earned', [
        'status' => 'completed'
    ]);
}

/**
 * Handle referral code from URL parameter
 */
add_action('init', function() {
    if (isset($_GET['ref']) && !is_user_logged_in()) {
        $referral_code = sanitize_text_field($_GET['ref']);
        // Store in session or cookie for later use when user registers/logs in
        setcookie('dollarbets_referral', $referral_code, time() + (30 * 24 * 60 * 60), '/'); // 30 days
    }
});

/**
 * Apply referral code when user registers
 */
add_action('user_register', function($user_id) {
    if (isset($_COOKIE['dollarbets_referral'])) {
        $referral_code = sanitize_text_field($_COOKIE['dollarbets_referral']);
        
        global $wpdb;
        $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
        
        // Find the referrer
        $referrer_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $user_stats_table WHERE referral_code = %s",
            $referral_code
        ));
        
        if ($referrer_stats && $referrer_stats->user_id != $user_id) {
            // Create user stats with referrer
            $user_referral_code = dollarbets_generate_referral_code($user_id);
            $wpdb->insert($user_stats_table, [
                'user_id' => $user_id,
                'referred_by' => $referrer_stats->user_id,
                'referral_code' => $user_referral_code
            ]);
            
            // Check if we should award bonus on signup
            $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
            if ($settings && $settings->is_enabled && $settings->reward_type === 'signup') {
                dollarbets_award_referral_bonus($referrer_stats->user_id, $settings->reward_amount);
            }
        }
        
        // Clear the cookie
        setcookie('dollarbets_referral', '', time() - 3600, '/');
    }
}, 10, 1);

/**
 * Award referral bonus on first bet
 */
add_action('dollarbets_first_bet_placed', function($user_id) {
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    if ($stats && $stats->referred_by) {
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
        if ($settings && $settings->is_enabled && $settings->reward_type === 'first_bet') {
            dollarbets_award_referral_bonus($stats->referred_by, $settings->reward_amount);
        }
    }
});

/**
 * Trigger first bet action in enhanced API
 */
add_action('init', function() {
    // This will be called from the place bet function when it's the user's first bet
    if (!function_exists('dollarbets_trigger_first_bet')) {
        function dollarbets_trigger_first_bet($user_id) {
            global $wpdb;
            $bets_table = $wpdb->prefix . 'dollarbets_bets';
            
            $bet_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $bets_table WHERE user_id = %d",
                $user_id
            ));
            
            if ($bet_count == 1) { // This is their first bet
                do_action('dollarbets_first_bet_placed', $user_id);
            }
        }
    }
});

/**
 * Add referral tab to Ultimate Member profile
 */
add_filter('um_profile_tabs', function($tabs) {
    global $wpdb;
    $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}dollarbets_referral_settings WHERE id = 1");
    
    if ($settings && $settings->is_enabled) {
        $tabs['referrals'] = [
            'name' => 'Referrals',
            'icon' => 'um-faicon-users',
            'custom' => true
        ];
    }
    
    return $tabs;
});

/**
 * Render referral tab content
 */
add_action('um_profile_content_referrals_default', function($args) {
    $user_id = um_profile_id();
    
    global $wpdb;
    $user_stats_table = $wpdb->prefix . 'dollarbets_user_stats';
    $referral_settings_table = $wpdb->prefix . 'dollarbets_referral_settings';
    
    $stats = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $user_stats_table WHERE user_id = %d",
        $user_id
    ));
    
    $settings = $wpdb->get_row("SELECT * FROM $referral_settings_table WHERE id = 1");
    
    if (!$stats || !$settings || !$settings->is_enabled) {
        echo '<p>Referral system is not available.</p>';
        return;
    }
    
    $referral_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $user_stats_table WHERE referred_by = %d",
        $user_id
    ));
    
    $referral_url = home_url('?ref=' . $stats->referral_code);
    
    ?>
    <div class="dollarbets-referral-tab">
        <div class="um-field">
            <div class="um-field-label">
                <label>Your Referral Code</label>
            </div>
            <div class="um-field-area">
                <input type="text" value="<?php echo esc_attr($stats->referral_code); ?>" readonly onclick="this.select();" style="font-family: monospace; font-weight: bold;">
            </div>
        </div>
        
        <div class="um-field">
            <div class="um-field-label">
                <label>Your Referral Link</label>
            </div>
            <div class="um-field-area">
                <input type="text" value="<?php echo esc_attr($referral_url); ?>" readonly onclick="this.select();" style="font-size: 12px;">
                <button type="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($referral_url); ?>'); alert('Copied to clipboard!');" style="margin-left: 10px;">Copy</button>
            </div>
        </div>
        
        <div class="um-field">
            <div class="um-field-label">
                <label>Referral Earnings</label>
            </div>
            <div class="um-field-area">
                <strong><?php echo number_format($stats->referral_earnings); ?> BetCoins</strong>
            </div>
        </div>
        
        <div class="um-field">
            <div class="um-field-label">
                <label>Total Referrals</label>
            </div>
            <div class="um-field-area">
                <strong><?php echo number_format($referral_count); ?> users</strong>
            </div>
        </div>
        
        <div class="um-field">
            <div class="um-field-label">
                <label>How it works</label>
            </div>
            <div class="um-field-area">
                <p><?php echo esc_html($settings->description); ?></p>
                <p><strong>Reward:</strong> <?php echo number_format($settings->reward_amount); ?> BetCoins per referral</p>
            </div>
        </div>
    </div>
    
    <style>
    .dollarbets-referral-tab .um-field {
        margin-bottom: 20px;
    }
    .dollarbets-referral-tab .um-field-label label {
        font-weight: bold;
        color: #333;
    }
    .dollarbets-referral-tab input[readonly] {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        padding: 8px 12px;
        border-radius: 4px;
        width: 100%;
        max-width: 400px;
    }
    </style>
    <?php
});

