<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Enhanced Admin Interface for DollarBets Platform
 * 
 * This file provides comprehensive admin controls for managing predictions,
 * users, packages, achievements, ranks, and all other platform features.
 */

// Add admin menu pages
add_action('admin_menu', 'dollarbets_add_admin_menus');

function dollarbets_add_admin_menus() {
    // Main menu page
    add_menu_page(
        'DollarBets Platform',
        'DollarBets',
        'manage_options',
        'dollarbets-dashboard',
        'dollarbets_render_dashboard',
        'dashicons-money-alt',
        56
    );

    // Predictions management
    add_submenu_page(
        'dollarbets-dashboard',
        'Manage Predictions',
        'Predictions',
        'manage_options',
        'dollarbets-predictions',
        'dollarbets_render_predictions_page'
    );

    // User stats
    add_submenu_page(
        'dollarbets-dashboard',
        'User Statistics',
        'User Stats',
        'manage_options',
        'dollarbets-user-stats',
        'dollarbets_render_user_stats_page'
    );

    // Transactions
    add_submenu_page(
        'dollarbets-dashboard',
        'All Transactions',
        'Transactions',
        'manage_options',
        'dollarbets-transactions',
        'dollarbets_render_transactions_page'
    );

    // Packages management
    add_submenu_page(
        'dollarbets-dashboard',
        'Manage Packages',
        'Packages',
        'manage_options',
        'dollarbets-packages',
        'dollarbets_render_packages_page'
    );

    // Achievements management
    add_submenu_page(
        'dollarbets-dashboard',
        'Manage Achievements',
        'Achievements',
        'manage_options',
        'dollarbets-achievements',
        'dollarbets_render_achievements_page'
    );

    // Ranks management
    add_submenu_page(
        'dollarbets-dashboard',
        'Manage Ranks',
        'Ranks',
        'manage_options',
        'dollarbets-ranks',
        'dollarbets_render_ranks_page'
    );

    // Referral settings
    add_submenu_page(
        'dollarbets-dashboard',
        'Referral Settings',
        'Referrals',
        'manage_options',
        'dollarbets-referrals',
        'dollarbets_render_referrals_page'
    );
}

// Dashboard page
function dollarbets_render_dashboard() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;
    
    // Get statistics
    $total_users = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}");
    $total_predictions = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'prediction' AND post_status = 'publish'");
    $total_bets = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}dollarbets_bets");
    $total_transactions = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}dollarbets_transactions");
    
    $recent_bets = $wpdb->get_results("
        SELECT b.*, p.post_title, u.display_name 
        FROM {$wpdb->prefix}dollarbets_bets b
        LEFT JOIN {$wpdb->posts} p ON b.prediction_id = p.ID
        LEFT JOIN {$wpdb->users} u ON b.user_id = u.ID
        ORDER BY b.created_at DESC
        LIMIT 10
    ");

    ?>
    <div class="wrap">
        <h1>DollarBets Dashboard</h1>
        
        <div class="dollarbets-dashboard-stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
            <div class="stat-card" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #3b82f6;">Total Users</h3>
                <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_users); ?></p>
            </div>
            <div class="stat-card" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #10b981;">Total Predictions</h3>
                <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_predictions); ?></p>
            </div>
            <div class="stat-card" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #f59e0b;">Total Bets</h3>
                <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_bets); ?></p>
            </div>
            <div class="stat-card" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h3 style="margin: 0 0 10px 0; color: #ef4444;">Total Transactions</h3>
                <p style="font-size: 24px; font-weight: bold; margin: 0;"><?php echo number_format($total_transactions); ?></p>
            </div>
        </div>

        <div class="dollarbets-recent-activity" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 20px;">
            <h2>Recent Bets</h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Prediction</th>
                        <th>Choice</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_bets as $bet): ?>
                    <tr>
                        <td><?php echo esc_html($bet->display_name); ?></td>
                        <td><?php echo esc_html($bet->post_title); ?></td>
                        <td>
                            <span style="padding: 4px 8px; border-radius: 4px; color: white; background: <?php echo $bet->bet_type === 'yes' ? '#10b981' : '#ef4444'; ?>;">
                                <?php echo strtoupper($bet->bet_type); ?>
                            </span>
                        </td>
                        <td><?php echo number_format($bet->amount); ?> BC</td>
                        <td><?php echo date('M j, Y g:i A', strtotime($bet->created_at)); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

// Predictions management page
function dollarbets_render_predictions_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    // Handle form submissions
    if ($_POST) {
        if (isset($_POST['resolve_prediction']) && wp_verify_nonce($_POST['_wpnonce'], 'resolve_prediction')) {
            $prediction_id = absint($_POST['prediction_id']);
            $result = sanitize_text_field($_POST['result']);
            
            if ($prediction_id && in_array($result, ['yes', 'no'])) {
                dollarbets_resolve_prediction($prediction_id, $result);
                echo '<div class="notice notice-success"><p>Prediction resolved successfully!</p></div>';
            }
        }
    }

    // Get predictions with bet data
    $predictions = $wpdb->get_results("
        SELECT p.*, 
               COALESCE(pd.total_bets_yes, 0) as total_bets_yes,
               COALESCE(pd.total_bets_no, 0) as total_bets_no,
               COALESCE(pd.status, 'active') as prediction_status
        FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->prefix}dollarbets_predictions pd ON p.ID = pd.post_id
        WHERE p.post_type = 'prediction' AND p.post_status = 'publish'
        ORDER BY p.post_date DESC
    ");

    ?>
    <div class="wrap">
        <h1>Manage Predictions</h1>
        
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Status</th>
                    <th>YES Bets</th>
                    <th>NO Bets</th>
                    <th>Total Volume</th>
                    <th>Expiry Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($predictions as $prediction): 
                    $expiry_date = get_post_meta($prediction->ID, 'prediction_expiry', true);
                    $is_expired = $expiry_date && strtotime($expiry_date) < time();
                    $total_volume = $prediction->total_bets_yes + $prediction->total_bets_no;
                ?>
                <tr>
                    <td>
                        <strong><?php echo esc_html($prediction->post_title); ?></strong>
                        <div style="font-size: 12px; color: #666;">ID: <?php echo $prediction->ID; ?></div>
                    </td>
                    <td>
                        <?php if ($prediction->prediction_status === 'resolved'): ?>
                            <span style="padding: 4px 8px; background: #059669; color: white; border-radius: 4px;">RESOLVED</span>
                        <?php elseif ($is_expired): ?>
                            <span style="padding: 4px 8px; background: #dc2626; color: white; border-radius: 4px;">EXPIRED</span>
                        <?php else: ?>
                            <span style="padding: 4px 8px; background: #10b981; color: white; border-radius: 4px;">ACTIVE</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo number_format($prediction->total_bets_yes); ?> BC</td>
                    <td><?php echo number_format($prediction->total_bets_no); ?> BC</td>
                    <td><?php echo number_format($total_volume); ?> BC</td>
                    <td><?php echo $expiry_date ? date('M j, Y g:i A', strtotime($expiry_date)) : 'No expiry'; ?></td>
                    <td>
                        <?php if ($prediction->prediction_status !== 'resolved'): ?>
                        <form method="post" style="display: inline-block;">
                            <?php wp_nonce_field('resolve_prediction'); ?>
                            <input type="hidden" name="prediction_id" value="<?php echo $prediction->ID; ?>">
                            <select name="result" required>
                                <option value="">Resolve as...</option>
                                <option value="yes">YES Wins</option>
                                <option value="no">NO Wins</option>
                            </select>
                            <button type="submit" name="resolve_prediction" class="button button-primary">Resolve</button>
                        </form>
                        <?php endif; ?>
                        <a href="<?php echo get_edit_post_link($prediction->ID); ?>" class="button">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// User statistics page
function dollarbets_render_user_stats_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    $users_stats = $wpdb->get_results("
        SELECT u.ID, u.display_name, u.user_email,
               COALESCE(us.total_bets, 0) as total_bets,
               COALESCE(us.total_wins, 0) as total_wins,
               COALESCE(us.total_losses, 0) as total_losses,
               COALESCE(us.win_rate, 0) as win_rate,
               COALESCE(us.current_streak, 0) as current_streak,
               COALESCE(us.rank_name, 'Bronze') as rank_name
        FROM {$wpdb->users} u
        LEFT JOIN {$wpdb->prefix}dollarbets_user_stats us ON u.ID = us.user_id
        ORDER BY us.total_bets DESC
    ");

    ?>
    <div class="wrap">
        <h1>User Statistics</h1>
        
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>User</th>
                    <th>Email</th>
                    <th>BetCoins</th>
                    <th>Rank</th>
                    <th>Total Bets</th>
                    <th>Wins</th>
                    <th>Losses</th>
                    <th>Win Rate</th>
                    <th>Current Streak</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users_stats as $user): 
                    $balance = gamipress_get_user_points($user->ID, 'betcoins');
                ?>
                <tr>
                    <td><?php echo esc_html($user->display_name); ?></td>
                    <td><?php echo esc_html($user->user_email); ?></td>
                    <td><?php echo number_format($balance); ?> BC</td>
                    <td>
                        <span style="padding: 4px 8px; background: #3b82f6; color: white; border-radius: 4px;">
                            <?php echo esc_html($user->rank_name); ?>
                        </span>
                    </td>
                    <td><?php echo number_format($user->total_bets); ?></td>
                    <td><?php echo number_format($user->total_wins); ?></td>
                    <td><?php echo number_format($user->total_losses); ?></td>
                    <td><?php echo number_format($user->win_rate, 1); ?>%</td>
                    <td><?php echo number_format($user->current_streak); ?></td>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=dollarbets-manage-points&user_id=' . $user->ID); ?>" class="button">Manage Points</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// Transactions page
function dollarbets_render_transactions_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    $page = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
    $per_page = 50;
    $offset = ($page - 1) * $per_page;

    $transactions = $wpdb->get_results($wpdb->prepare("
        SELECT t.*, u.display_name
        FROM {$wpdb->prefix}dollarbets_transactions t
        LEFT JOIN {$wpdb->users} u ON t.user_id = u.ID
        ORDER BY t.created_at DESC
        LIMIT %d OFFSET %d
    ", $per_page, $offset));

    $total_transactions = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}dollarbets_transactions");
    $total_pages = ceil($total_transactions / $per_page);

    ?>
    <div class="wrap">
        <h1>All Transactions</h1>
        
        <table class="widefat striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Balance Before</th>
                    <th>Balance After</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction): ?>
                <tr>
                    <td><?php echo $transaction->id; ?></td>
                    <td><?php echo esc_html($transaction->display_name); ?></td>
                    <td>
                        <span style="padding: 4px 8px; border-radius: 4px; color: white; background: <?php 
                            echo match($transaction->transaction_type) {
                                'bet' => '#f59e0b',
                                'win' => '#10b981',
                                'award' => '#3b82f6',
                                'deduct' => '#ef4444',
                                'referral' => '#8b5cf6',
                                default => '#6b7280'
                            };
                        ?>;">
                            <?php echo strtoupper($transaction->transaction_type); ?>
                        </span>
                    </td>
                    <td><?php echo number_format($transaction->amount); ?> BC</td>
                    <td><?php echo number_format($transaction->balance_before); ?> BC</td>
                    <td><?php echo number_format($transaction->balance_after); ?> BC</td>
                    <td><?php echo esc_html($transaction->description); ?></td>
                    <td><?php echo esc_html($transaction->status); ?></td>
                    <td><?php echo date('M j, Y g:i A', strtotime($transaction->created_at)); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <?php if ($total_pages > 1): ?>
        <div class="tablenav">
            <div class="tablenav-pages">
                <?php
                echo paginate_links([
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => $total_pages,
                    'current' => $page
                ]);
                ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// Packages management page
function dollarbets_render_packages_page() {
    if (!current_user_can('manage_options')) return;

    global $wpdb;

    // Handle form submissions
    if ($_POST) {
        if (isset($_POST['add_package']) && wp_verify_nonce($_POST['_wpnonce'], 'add_package')) {
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $betcoins_amount = absint($_POST['betcoins_amount']);
            $price = floatval($_POST['price']);
            $currency = sanitize_text_field($_POST['currency']);
            
            $wpdb->insert($wpdb->prefix . 'dollarbets_packages', [
                'name' => $name,
                'description' => $description,
                'betcoins_amount' => $betcoins_amount,
                'price' => $price,
                'currency' => $currency,
                'is_active' => 1
            ]);
            
            echo '<div class="notice notice-success"><p>Package added successfully!</p></div>';
        }
        
        if (isset($_POST['update_package']) && wp_verify_nonce($_POST['_wpnonce'], 'update_package')) {
            $package_id = absint($_POST['package_id']);
            $name = sanitize_text_field($_POST['name']);
            $description = sanitize_textarea_field($_POST['description']);
            $betcoins_amount = absint($_POST['betcoins_amount']);
            $price = floatval($_POST['price']);
            $currency = sanitize_text_field($_POST['currency']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            $wpdb->update($wpdb->prefix . 'dollarbets_packages', [
                'name' => $name,
                'description' => $description,
                'betcoins_amount' => $betcoins_amount,
                'price' => $price,
                'currency' => $currency,
                'is_active' => $is_active
            ], ['id' => $package_id]);
            
            echo '<div class="notice notice-success"><p>Package updated successfully!</p></div>';
        }
    }

    $packages = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}dollarbets_packages ORDER BY sort_order ASC");

    ?>
    <div class="wrap">
        <h1>Manage Packages</h1>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Add new package form -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Add New Package</h2>
                <form method="post">
                    <?php wp_nonce_field('add_package'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label for="name">Package Name</label></th>
                            <td><input type="text" name="name" id="name" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th><label for="description">Description</label></th>
                            <td><textarea name="description" id="description" class="large-text" rows="3"></textarea></td>
                        </tr>
                        <tr>
                            <th><label for="betcoins_amount">BetCoins Amount</label></th>
                            <td><input type="number" name="betcoins_amount" id="betcoins_amount" min="1" required></td>
                        </tr>
                        <tr>
                            <th><label for="price">Price</label></th>
                            <td><input type="number" name="price" id="price" step="0.01" min="0" required></td>
                        </tr>
                        <tr>
                            <th><label for="currency">Currency</label></th>
                            <td>
                                <select name="currency" id="currency">
                                    <option value="USD">USD</option>
                                    <option value="EUR">EUR</option>
                                    <option value="GBP">GBP</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    <button type="submit" name="add_package" class="button button-primary">Add Package</button>
                </form>
            </div>

            <!-- Existing packages -->
            <div style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2>Existing Packages</h2>
                <?php foreach ($packages as $package): ?>
                <div style="border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 6px;">
                    <form method="post">
                        <?php wp_nonce_field('update_package'); ?>
                        <input type="hidden" name="package_id" value="<?php echo $package->id; ?>">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Name:</label>
                                <input type="text" name="name" value="<?php echo esc_attr($package->name); ?>" class="regular-text" required>
                            </div>
                            <div>
                                <label>BetCoins:</label>
                                <input type="number" name="betcoins_amount" value="<?php echo $package->betcoins_amount; ?>" min="1" required>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 10px;">
                            <label>Description:</label>
                            <textarea name="description" class="large-text" rows="2"><?php echo esc_textarea($package->description); ?></textarea>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <label>Price:</label>
                                <input type="number" name="price" value="<?php echo $package->price; ?>" step="0.01" min="0" required>
                            </div>
                            <div>
                                <label>Currency:</label>
                                <select name="currency">
                                    <option value="USD" <?php selected($package->currency, 'USD'); ?>>USD</option>
                                    <option value="EUR" <?php selected($package->currency, 'EUR'); ?>>EUR</option>
                                    <option value="GBP" <?php selected($package->currency, 'GBP'); ?>>GBP</option>
                                </select>
                            </div>
                            <div>
                                <label>
                                    <input type="checkbox" name="is_active" <?php checked($package->is_active, 1); ?>>
                                    Active
                                </label>
                            </div>
                        </div>
                        
                        <button type="submit" name="update_package" class="button button-primary">Update</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
}

// Function to resolve predictions and distribute winnings
if (!function_exists('dollarbets_resolve_prediction')) {
    function dollarbets_resolve_prediction($prediction_id, $result) {
    global $wpdb;
    
    // Update prediction status
    $predictions_table = $wpdb->prefix . 'dollarbets_predictions';
    $wpdb->query($wpdb->prepare(
        "UPDATE $predictions_table SET status = 'resolved' WHERE post_id = %d",
        $prediction_id
    ));
    
    // Get all bets for this prediction
    $bets_table = $wpdb->prefix . 'dollarbets_bets';
    $bets = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $bets_table WHERE prediction_id = %d",
        $prediction_id
    ));
    
    // Calculate total winning and losing amounts
    $total_winning_amount = 0;
    $total_losing_amount = 0;
    $winning_bets = [];
    $losing_bets = [];
    
    foreach ($bets as $bet) {
        if ($bet->bet_type === $result) {
            $winning_bets[] = $bet;
            $total_winning_amount += $bet->amount;
        } else {
            $losing_bets[] = $bet;
            $total_losing_amount += $bet->amount;
        }
    }
    
    // Distribute winnings proportionally
    if ($total_winning_amount > 0) {
        $total_pool = $total_winning_amount + $total_losing_amount;
        
        foreach ($winning_bets as $bet) {
            // Calculate proportional winnings
            $proportion = $bet->amount / $total_winning_amount;
            $winnings = round($total_pool * $proportion);
            
            // Award winnings
            gamipress_add_points($bet->user_id, $winnings, 'betcoins', [
                'reason' => 'Prediction winnings for: ' . get_the_title($prediction_id)
            ]);
            
            // Update user stats
            dollarbets_update_user_stats($bet->user_id, 'win', $winnings);
        }
        
        // Update losing users' stats
        foreach ($losing_bets as $bet) {
            dollarbets_update_user_stats($bet->user_id, 'loss', 0);
        }
    }
    
    // Add post meta to mark as resolved
    update_post_meta($prediction_id, 'prediction_resolved', $result);
    update_post_meta($prediction_id, 'prediction_resolved_date', current_time('mysql'));
}


}