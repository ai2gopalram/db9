<div id="dollarbets-root">
    <!-- React will mount here -->
</div>
