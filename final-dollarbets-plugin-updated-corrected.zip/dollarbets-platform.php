<?php
/*
Plugin Name: DollarBets Platform
Description:  Prediction market with BetCoins (GamiPress), Ultimate Member, NewsAPI integration, and frontend prediction tiles.
Version: 1.0
Author: DolleBets
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define reusable paths
define('DOLLARBETS_PATH', plugin_dir_path(__FILE__));
define('DOLLARBETS_URL', plugin_dir_url(__FILE__));

// -----------------------------------------------------------------------------
// Include DollarBets custom points system and settings
// -----------------------------------------------------------------------------
// These files provide fallback implementations for GamiPress point functions
// and expose an admin interface for configuring coin types and rank thresholds.
require_once DOLLARBETS_PATH . 'includes/custom-database.php';
require_once DOLLARBETS_PATH . 'includes/db-points-system.php';
require_once DOLLARBETS_PATH . 'includes/points-settings.php';

// Activation hook
register_activation_hook(__FILE__, 'dollarbets_activate_plugin');
function dollarbets_activate_plugin() {
    // Create all custom database tables
    dollarbets_create_custom_tables();
    
    // Flush rewrite rules
    if (function_exists('flush_rewrite_rules')) {
        flush_rewrite_rules();
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'dollarbets_deactivate_plugin');
function dollarbets_deactivate_plugin() {
    // Flush rewrite rules
    if (function_exists('flush_rewrite_rules')) {
        flush_rewrite_rules();
    }
}

// Load core components
require_once DOLLARBETS_PATH . 'includes/custom-post-types.php';
require_once DOLLARBETS_PATH . 'includes/enqueue-scripts.php';
require_once DOLLARBETS_PATH . 'includes/admin-settings.php';
require_once DOLLARBETS_PATH . 'includes/admin-enhanced.php';
require_once DOLLARBETS_PATH . 'includes/admin-achievements-ranks.php';
require_once DOLLARBETS_PATH . 'includes/toggle-mode.php';
require_once DOLLARBETS_PATH . 'includes/header-enhancements.php';
require_once DOLLARBETS_PATH . 'includes/payment-gateway.php';
require_once DOLLARBETS_PATH . 'includes/transaction-history.php';
require_once DOLLARBETS_PATH . 'includes/prediction-resolution.php';
require_once DOLLARBETS_PATH . 'includes/ultimate-member-transactions.php';
require_once DOLLARBETS_PATH . 'includes/payout-system.php';
require_once DOLLARBETS_PATH . 'includes/leaderboard.php';
require_once DOLLARBETS_PATH . 'includes/ultimate-member-hooks.php';
require_once DOLLARBETS_PATH . 'includes/news-api-integration.php';
require_once DOLLARBETS_PATH . 'includes/payment-settings.php';
require_once DOLLARBETS_PATH . 'shortcodes/predictions.php';
require_once DOLLARBETS_PATH . 'includes/rest-api-enhanced.php';
require_once DOLLARBETS_PATH . 'includes/referral-system.php';
require_once DOLLARBETS_PATH . 'includes/achievement-checker.php';



require_once DOLLARBETS_PATH . 'includes/elementor-compatibility.php';


require_once DOLLARBETS_PATH . 'shortcodes/user-info.php';

// -----------------------------------------------------------------------------
// Admin: BetCoins Points Overview Page
// -----------------------------------------------------------------------------
// To give administrators a quick overview of user balances, add a top‑level
// menu page in the WordPress admin that lists all users and their current
// BetCoins balance.  This replicates the kind of points overview that
// GamiPress provided and makes it easy to audit user earnings.

add_action('admin_menu', function() {
    // Top‑level menu icon 'dashicons-money-alt' is used to represent currency.
    add_menu_page(
        'BetCoins Points Overview',            // Page title
        'BetCoins Points',                     // Menu title
        'manage_options',                      // Capability
        'dollarbets-points-overview',          // Menu slug
        'dollarbets_render_points_overview',   // Callback function
        'dashicons-money-alt',                 // Icon
        56                                     // Position
    );
});

// -----------------------------------------------------------------------------
// Admin: Manage BetCoins Page
// -----------------------------------------------------------------------------
// Provide an interface for administrators to manually award or deduct BetCoins
// from any user.  This complements the points overview and gives site owners
// direct control over balances without needing GamiPress.
add_action('admin_menu', function() {
    // Add as a sub‑menu under the BetCoins Points overview menu
    add_submenu_page(
        'dollarbets-points-overview',
        'Manage BetCoins',
        'Manage BetCoins',
        'manage_options',
        'dollarbets-manage-points',
        'dollarbets_render_manage_points_page'
    );
});

/**
 * Render the Manage BetCoins admin page.
 * Allows admins to select a user, specify an amount, choose add/deduct, and
 * provide a reason.  Submits the form to itself via POST and updates the
 * user's balance using the custom points functions defined in db-points-system.php.
 */
function dollarbets_render_manage_points_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $message = '';
    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dollarbets_manage_points_nonce']) && wp_verify_nonce($_POST['dollarbets_manage_points_nonce'], 'dollarbets_manage_points')) {
        $target_user = absint($_POST['target_user'] ?? 0);
        $amount      = intval($_POST['points_amount'] ?? 0);
        $reason      = sanitize_text_field($_POST['reason'] ?? '');
        $action_type = sanitize_text_field($_POST['action_type'] ?? 'add');
        if ($target_user && $amount > 0) {
            if ($action_type === 'add') {
                if (function_exists('gamipress_add_points')) {
                    gamipress_add_points($target_user, $amount, 'betcoins', ['reason' => $reason ?: 'Admin manual addition']);
                }
                $message = sprintf('Successfully added %s BetCoins to user ID %d.', number_format_i18n($amount), $target_user);
            } elseif ($action_type === 'deduct') {
                if (function_exists('gamipress_deduct_points')) {
                    gamipress_deduct_points($target_user, $amount, 'betcoins', ['reason' => $reason ?: 'Admin manual deduction']);
                }
                $message = sprintf('Successfully deducted %s BetCoins from user ID %d.', number_format_i18n($amount), $target_user);
            }
        } else {
            $message = 'Please select a user and enter a valid amount.';
        }
    }
    // Fetch users for dropdown
    $users = get_users();
    echo '<div class="wrap">';
    echo '<h1>Manage BetCoins</h1>';
    if (!empty($message)) {
        echo '<div class="notice notice-success"><p>' . esc_html($message) . '</p></div>';
    }
    echo '<p>Use this form to manually add or deduct BetCoins from a user.</p>';
    echo '<form method="post">';
    wp_nonce_field('dollarbets_manage_points', 'dollarbets_manage_points_nonce');
    echo '<table class="form-table" style="max-width:600px"><tbody>';
    echo '<tr><th scope="row"><label for="target_user">User</label></th><td><select name="target_user" id="target_user">';
    echo '<option value="">Select a user</option>';
    foreach ($users as $user) {
        echo '<option value="' . esc_attr($user->ID) . '">' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ')</option>';
    }
    echo '</select></td></tr>';
    echo '<tr><th scope="row"><label for="points_amount">Amount</label></th><td><input type="number" name="points_amount" id="points_amount" min="1" step="1" required></td></tr>';
    echo '<tr><th scope="row"><label for="reason">Reason</label></th><td><input type="text" name="reason" id="reason" class="regular-text"></td></tr>';
    echo '<tr><th scope="row">Action</th><td>';
    echo '<label><input type="radio" name="action_type" value="add" checked> Add</label> ';
    echo '<label><input type="radio" name="action_type" value="deduct"> Deduct</label>';
    echo '</td></tr>';
    echo '</tbody></table>';
    submit_button('Submit');
    echo '</form>';
    echo '</div>';
}

/**
 * Render the BetCoins points overview admin page.
 * Lists all registered users along with their current BetCoins balance.
 */
function dollarbets_render_points_overview() {
    if (!current_user_can('manage_options')) {
        return;
    }
    echo '<div class="wrap"><h1>BetCoins Points Overview</h1>';
    echo '<p>This table shows the current BetCoins balance for every user on the site.</p>';
    $users = get_users();
    echo '<table class="widefat striped" style="max-width:800px"><thead><tr><th>User ID</th><th>User</th><th>BetCoins Balance</th></tr></thead><tbody>';
    foreach ($users as $user) {
        // Use our points function to retrieve the balance; fallback returns 0.
        $balance = 0;
        if (function_exists('gamipress_get_user_points')) {
            $balance = gamipress_get_user_points($user->ID, 'betcoins');
        }
        echo '<tr><td>' . esc_html($user->ID) . '</td><td>' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ')</td><td>' . number_format_i18n($balance) . ' BC</td></tr>';
    }
    echo '</tbody></table></div>';
}


function dollarbets_create_prediction_page() {
    echo '<h1>Create New Prediction</h1>';
    // Display form for creating new predictions manually
    echo '<form method="post">';
    echo '<label for="prediction_title">Prediction Title:</label>';
    echo '<input type="text" id="prediction_title" name="prediction_title" required>';
    echo '<label for="prediction_category">Category:</label>';
    echo '<input type="text" id="prediction_category" name="prediction_category" required>';
    echo '<input type="submit" value="Create Prediction">';
    echo '</form>';

    // Handle form submission to create prediction
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $title = sanitize_text_field($_POST['prediction_title']);
        $category = sanitize_text_field($_POST['prediction_category']);

        $post_data = [
            'post_title' => $title,
            'post_type' => 'prediction',
            'post_status' => 'publish',
            'meta_input' => ['prediction_category' => $category]
        ];

        $post_id = wp_insert_post($post_data);

        if ($post_id) {
            echo '<p>Prediction Created: <a href="' . get_edit_post_link($post_id) . '">Edit Prediction</a></p>';
        } else {
            echo '<p>Error creating prediction.</p>';
        }
    }
}
