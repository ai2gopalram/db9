document.addEventListener('DOMContentLoaded', function () {
  const { useState, useEffect } = React;

  function PredictionApp() {
    const [predictions, setPredictions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeBet, setActiveBet] = useState(null);
    const [remainingCoins, setRemainingCoins] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(dollarbetsConfig.isLoggedIn);
    const [n

document.addEventListener('DOMContentLoaded', function () {
  const { useState, useEffect } = React;

  function PredictionApp() {
    const [predictions, setPredictions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState(false);
    const [activeBet, setActiveBet] = useState(null);
    const [remainingCoins, setRemainingCoins] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [isLoggedIn, setIsLogg