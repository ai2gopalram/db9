document.addEventListener('DOMContentLoaded', function () {
  const { useState, useEffect } = React;

  function PredictionApp() {
    const [predictions, setPredictions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [loadingMore, setLoadingMore] = useState(false);
    const [activeBet, setActiveBet] = useState(null);
    const [remainingCoins, setRemainingCoins] = useState(null);
    const [inputValue, setInputValue] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(dollarbetsConfig.isLoggedIn);
    const [notice, setNotice] = useState(null);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [categories, setCategories] = useState(['All']);
    const [showInsufficientFunds, setShowInsufficientFunds] = useState(null);
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const [userBets, setUserBets] = useState({});
    const [showPackages, setShowPackages] = useState(false);
    const [packages, setPackages] = useState([]);

    // Load dark mode preference from localStorage on component mount
    useEffect(() => {
      const savedDarkMode = localStorage.getItem('dollarbets-dark-mode');
      if (savedDarkMode !== null) {
        setIsDarkMode(JSON.parse(savedDarkMode));
      }
    }, []);

    // Listen for dark mode changes from header toggle
    useEffect(() => {
      const handleDarkModeChange = (event) => {
        setIsDarkMode(event.detail.isDarkMode);
      };

      window.addEventListener('dollarbets-dark-mode-changed', handleDarkModeChange);

      const handleStorageChange = (event) => {
        if (event.key === 'dollarbets-dark-mode') {
          setIsDarkMode(JSON.parse(event.newValue));
        }
      };

      window.addEventListener('storage', handleStorageChange);

      return () => {
        window.removeEventListener('dollarbets-dark-mode-changed', handleDarkModeChange);
        window.removeEventListener('storage', handleStorageChange);
      };
    }, []);

    // Save dark mode preference to localStorage whenever it changes
    useEffect(() => {
      localStorage.setItem('dollarbets-dark-mode', JSON.stringify(isDarkMode));
      
      if (isDarkMode) {
        document.body.classList.add('dollarbets-dark-mode');
      } else {
        document.body.classList.remove('dollarbets-dark-mode');
      }

      const headerToggle = document.getElementById('dollarbets-dark-toggle');
      if (headerToggle) {
        headerToggle.checked = !isDarkMode;
        
        const toggleBg = document.getElementById('toggle-bg');
        const toggleDot = document.getElementById('toggle-dot');
        if (toggleBg && toggleDot) {
          if (isDarkMode) {
            toggleBg.style.backgroundColor = '#4b5563';
            toggleDot.classList.remove('translate-x-6');
          } else {
            toggleBg.style.backgroundColor = '#3b82f6';
            toggleDot.classList.add('translate-x-6');
          }
        }
      }
    }, [isDarkMode]);

    // Expose setDarkMode function to global scope for header toggle
    useEffect(() => {
      window.dollarbetsApp = {
        setDarkMode: setIsDarkMode
      };

      return () => {
        delete window.dollarbetsApp;
      };
    }, []);

    function showNotice(message, type = 'info', targetId = null, duration = 3000) {
      setNotice({ message, type, targetId });
      if (duration > 0) {
        setTimeout(() => setNotice(null), duration);
      }
    }

    // Fetch user balance
    useEffect(() => {
      const fetchUserBalance = async () => {
        if (!isLoggedIn) {
          setRemainingCoins(0);
          return;
        }

        try {
          const response = await fetch(dollarbetsConfig.restUrl + 'dollarbets/v1/user-balance', {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': dollarbetsConfig.nonce,
            },
            credentials: 'include',
          });

          if (response.ok) {
            const data = await response.json();
            setRemainingCoins(data.balance || 0);
          } else {
            setRemainingCoins(0);
          }
        } catch (error) {
          console.error("❌ Failed to fetch balance:", error);
          setRemainingCoins(0);
        }
      };

      fetchUserBalance();
    }, [isLoggedIn]);

    // Fetch predictions with pagination
    const fetchPredictions = async (page = 1, append = false) => {
      try {
        if (page === 1) setLoading(true);
        else setLoadingMore(true);

        const response = await fetch(
          `${dollarbetsConfig.restUrl}dollarbets/v1/predictions?page=${page}`,
          {
            headers: {
              'X-WP-Nonce': dollarbetsConfig.nonce,
            },
            credentials: 'include',
          }
        );

        if (response.ok) {
          const data = await response.json();
          
          if (append) {
            setPredictions(prev => [...prev, ...data.predictions]);
          } else {
            setPredictions(data.predictions);
          }

          setHasMore(data.pagination.has_more);
          setCurrentPage(page);

          // Extract categories
          const allCategories = [...new Set(['All', ...data.predictions.map(p => p.category || 'General')])];
          setCategories(allCategories);
        }
      } catch (error) {
        console.error('❌ Failed to load predictions:', error);
        showNotice('Failed to load predictions', 'error');
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    };

    // Initial load
    useEffect(() => {
      fetchPredictions(1);
    }, []);

    // Load more predictions
    const loadMorePredictions = () => {
      if (!loadingMore && hasMore) {
        fetchPredictions(currentPage + 1, true);
      }
    };

    // Infinite scroll
    useEffect(() => {
      const handleScroll = () => {
        if (window.innerHeight + document.documentElement.scrollTop >= document.documentElement.offsetHeight - 1000) {
          loadMorePredictions();
        }
      };

      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    }, [loadingMore, hasMore, currentPage]);

    // Fetch packages
    useEffect(() => {
      const fetchPackages = async () => {
        try {
          const response = await fetch(dollarbetsConfig.restUrl + 'dollarbets/v1/packages');
          if (response.ok) {
            const data = await response.json();
            setPackages(data);
          }
        } catch (error) {
          console.error('Failed to fetch packages:', error);
        }
      };

      fetchPackages();
    }, []);

    function showInsufficientFundsModal(amount, balance, predictionId) {
      setShowInsufficientFunds({
        amount,
        balance,
        predictionId
      });
    }

    function handleAddBetCoins() {
      setShowPackages(true);
    }

    async function submitBet() {
      const amount = parseInt(inputValue);
      if (!amount || isNaN(amount) || amount <= 0) {
        showNotice('❗ Please enter a valid BetCoin amount.', 'error', activeBet?.id);
        return;
      }
      
      if (!isLoggedIn) {
        // Show login form
        if (typeof UM !== 'undefined' && typeof UM.modal !== 'undefined') {
          UM.modal.open({ src: 'login' });
        } else {
          showNotice("❗ Please log in to place a bet.", "error", activeBet?.id);
        }
        return;
      }
      
      if (amount > remainingCoins) {
        showInsufficientFundsModal(amount, remainingCoins, activeBet.id);
        return;
      }

      try {
        const response = await fetch(dollarbetsConfig.restUrl + 'dollarbets/v1/place-bet', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': dollarbetsConfig.nonce,
          },
          credentials: 'include',
          body: JSON.stringify({
            prediction_id: activeBet.id,
            choice: activeBet.choice,
            amount: amount,
          }),
        });

        const result = await response.json();

        if (response.ok && result.success) {
          setRemainingCoins(result.new_balance);
          setActiveBet(null);
          setInputValue('');
          showNotice(`✅ Bet placed successfully! New balance: ${result.formatted_balance} BetCoins`, 'success');
          
          // Refresh predictions to show updated vote counts
          fetchPredictions(1);
        } else {
          showNotice(`❌ ${result.message || 'Failed to place bet'}`, 'error', activeBet?.id);
        }
      } catch (error) {
        console.error('❌ Bet submission failed:', error);
        showNotice('❌ Network error. Please try again.', 'error', activeBet?.id);
      }
    }

    function openBetModal(prediction, choice) {
      // Check if prediction is expired
      if (prediction.is_expired) {
        showNotice('❌ Betting Closed - This prediction has expired', 'error', prediction.id);
        return;
      }

      // Check if user already bet
      if (prediction.user_bet) {
        showNotice('❌ You have already placed a bet on this prediction', 'error', prediction.id);
        return;
      }

      if (!isLoggedIn) {
        // Show login form
        if (typeof UM !== 'undefined' && typeof UM.modal !== 'undefined') {
          UM.modal.open({ src: 'login' });
        } else {
          showNotice("❗ Please log in to place a bet.", "error", prediction.id);
        }
        return;
      }

      setActiveBet({ id: prediction.id, choice, title: prediction.title });
      setInputValue('');
    }

    function closeBetModal() {
      setActiveBet(null);
      setInputValue('');
    }

    const filteredPredictions = selectedCategory === 'All' 
      ? predictions 
      : predictions.filter(p => (p.category || 'General') === selectedCategory);

    return React.createElement('div', { className: `prediction-app ${isDarkMode ? 'dark-mode' : ''}` }, [
      // Header with balance
      React.createElement('div', { 
        key: 'header',
        className: 'prediction-header',
        style: {
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '20px',
          padding: '15px',
          backgroundColor: isDarkMode ? '#1f2937' : '#f8fafc',
          borderRadius: '8px',
          border: isDarkMode ? '1px solid #374151' : '1px solid #e2e8f0'
        }
      }, [
        React.createElement('h2', { 
          key: 'title',
          style: { margin: 0, color: isDarkMode ? '#f9fafb' : '#1f2937' }
        }, 'Live Predictions'),
        
        isLoggedIn && React.createElement('div', {
          key: 'balance',
          className: 'balance-display',
          style: {
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            padding: '8px 16px',
            backgroundColor: isDarkMode ? '#374151' : '#ffffff',
            borderRadius: '6px',
            border: isDarkMode ? '1px solid #4b5563' : '1px solid #d1d5db'
          }
        }, [
          React.createElement('span', {
            key: 'coin-icon',
            style: { fontSize: '18px' }
          }, '💰'),
          React.createElement('span', {
            key: 'balance-text',
            style: { 
              fontWeight: 'bold',
              color: isDarkMode ? '#f9fafb' : '#1f2937'
            }
          }, `${remainingCoins !== null ? remainingCoins.toLocaleString() : '0'} BetCoins`),
          React.createElement('button', {
            key: 'add-coins',
            onClick: handleAddBetCoins,
            style: {
              marginLeft: '10px',
              padding: '4px 8px',
              fontSize: '12px',
              backgroundColor: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }
          }, '+')
        ])
      ]),

      // Category filter
      React.createElement('div', {
        key: 'category-filter',
        className: 'category-filter',
        style: {
          marginBottom: '20px',
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap'
        }
      }, categories.map(category => 
        React.createElement('button', {
          key: category,
          onClick: () => setSelectedCategory(category),
          style: {
            padding: '8px 16px',
            border: 'none',
            borderRadius: '20px',
            cursor: 'pointer',
            backgroundColor: selectedCategory === category 
              ? '#3b82f6' 
              : (isDarkMode ? '#374151' : '#f1f5f9'),
            color: selectedCategory === category 
              ? 'white' 
              : (isDarkMode ? '#f9fafb' : '#475569')
          }
        }, category)
      )),

      // Loading state
      loading && React.createElement('div', {
        key: 'loading',
        style: {
          textAlign: 'center',
          padding: '40px',
          color: isDarkMode ? '#9ca3af' : '#6b7280'
        }
      }, 'Loading predictions...'),

      // Predictions grid
      !loading && React.createElement('div', {
        key: 'predictions-grid',
        className: 'predictions-grid',
        style: {
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
          gap: '20px',
          marginBottom: '20px'
        }
      }, filteredPredictions.map(prediction => 
        React.createElement('div', {
          key: prediction.id,
          className: 'prediction-card',
          style: {
            backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
            border: isDarkMode ? '1px solid #374151' : '1px solid #e5e7eb',
            borderRadius: '12px',
            padding: '20px',
            boxShadow: isDarkMode ? '0 4px 6px rgba(0, 0, 0, 0.3)' : '0 4px 6px rgba(0, 0, 0, 0.1)'
          }
        }, [
          // Prediction title
          React.createElement('h3', {
            key: 'title',
            style: {
              margin: '0 0 12px 0',
              fontSize: '18px',
              fontWeight: 'bold',
              color: isDarkMode ? '#f9fafb' : '#1f2937'
            }
          }, prediction.title),

          // Prediction content
          React.createElement('div', {
            key: 'content',
            style: {
              marginBottom: '16px',
              color: isDarkMode ? '#d1d5db' : '#4b5563',
              fontSize: '14px',
              lineHeight: '1.5'
            },
            dangerouslySetInnerHTML: { __html: prediction.content }
          }),

          // Status indicators
          React.createElement('div', {
            key: 'status',
            style: {
              marginBottom: '16px',
              display: 'flex',
              gap: '8px',
              flexWrap: 'wrap'
            }
          }, [
            prediction.is_expired && React.createElement('span', {
              key: 'expired',
              style: {
                padding: '4px 8px',
                backgroundColor: '#dc2626',
                color: 'white',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: 'bold'
              }
            }, 'BETTING CLOSED'),

            prediction.user_bet && React.createElement('span', {
              key: 'user-bet',
              style: {
                padding: '4px 8px',
                backgroundColor: '#059669',
                color: 'white',
                borderRadius: '12px',
                fontSize: '12px',
                fontWeight: 'bold'
              }
            }, `YOU BET ${prediction.user_bet.choice.toUpperCase()} (${prediction.user_bet.amount} BC)`)
          ]),

          // Vote percentages
          React.createElement('div', {
            key: 'percentages',
            style: {
              marginBottom: '16px',
              display: 'flex',
              gap: '8px'
            }
          }, [
            React.createElement('div', {
              key: 'yes-percentage',
              style: {
                flex: 1,
                textAlign: 'center',
                padding: '8px',
                backgroundColor: '#10b981',
                color: 'white',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: 'bold'
              }
            }, `YES ${prediction.percentage_yes}%`),
            React.createElement('div', {
              key: 'no-percentage',
              style: {
                flex: 1,
                textAlign: 'center',
                padding: '8px',
                backgroundColor: '#ef4444',
                color: 'white',
                borderRadius: '6px',
                fontSize: '14px',
                fontWeight: 'bold'
              }
            }, `NO ${prediction.percentage_no}%`)
          ]),

          // Vote counts
          React.createElement('div', {
            key: 'vote-counts',
            style: {
              marginBottom: '16px',
              fontSize: '12px',
              color: isDarkMode ? '#9ca3af' : '#6b7280',
              textAlign: 'center'
            }
          }, `Total votes: ${prediction.total_votes} BetCoins`),

          // Betting buttons
          !prediction.is_expired && !prediction.user_bet && React.createElement('div', {
            key: 'betting-buttons',
            style: {
              display: 'flex',
              gap: '8px'
            }
          }, [
            React.createElement('button', {
              key: 'bet-yes',
              onClick: () => openBetModal(prediction, 'yes'),
              style: {
                flex: 1,
                padding: '12px',
                backgroundColor: '#10b981',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }
            }, 'BET YES'),
            React.createElement('button', {
              key: 'bet-no',
              onClick: () => openBetModal(prediction, 'no'),
              style: {
                flex: 1,
                padding: '12px',
                backgroundColor: '#ef4444',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                fontWeight: 'bold',
                cursor: 'pointer'
              }
            }, 'BET NO')
          ])
        ])
      )),

      // Load more button
      !loading && hasMore && React.createElement('div', {
        key: 'load-more',
        style: {
          textAlign: 'center',
          marginTop: '20px'
        }
      }, React.createElement('button', {
        onClick: loadMorePredictions,
        disabled: loadingMore,
        style: {
          padding: '12px 24px',
          backgroundColor: '#3b82f6',
          color: 'white',
          border: 'none',
          borderRadius: '6px',
          cursor: loadingMore ? 'not-allowed' : 'pointer',
          opacity: loadingMore ? 0.6 : 1
        }
      }, loadingMore ? 'Loading...' : 'Load More')),

      // Bet modal
      activeBet && React.createElement('div', {
        key: 'bet-modal',
        className: 'modal-overlay',
        style: {
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        },
        onClick: (e) => {
          if (e.target === e.currentTarget) closeBetModal();
        }
      }, React.createElement('div', {
        style: {
          backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
          padding: '24px',
          borderRadius: '12px',
          maxWidth: '400px',
          width: '90%',
          maxHeight: '90vh',
          overflow: 'auto'
        }
      }, [
        React.createElement('h3', {
          key: 'modal-title',
          style: {
            margin: '0 0 16px 0',
            color: isDarkMode ? '#f9fafb' : '#1f2937'
          }
        }, `Place ${activeBet.choice.toUpperCase()} bet`),
        
        React.createElement('p', {
          key: 'modal-subtitle',
          style: {
            margin: '0 0 16px 0',
            color: isDarkMode ? '#d1d5db' : '#4b5563',
            fontSize: '14px'
          }
        }, activeBet.title),

        React.createElement('input', {
          key: 'amount-input',
          type: 'number',
          placeholder: 'Enter BetCoin amount',
          value: inputValue,
          onChange: (e) => setInputValue(e.target.value),
          style: {
            width: '100%',
            padding: '12px',
            border: isDarkMode ? '1px solid #4b5563' : '1px solid #d1d5db',
            borderRadius: '6px',
            marginBottom: '16px',
            backgroundColor: isDarkMode ? '#374151' : '#ffffff',
            color: isDarkMode ? '#f9fafb' : '#1f2937'
          }
        }),

        React.createElement('div', {
          key: 'modal-buttons',
          style: {
            display: 'flex',
            gap: '8px'
          }
        }, [
          React.createElement('button', {
            key: 'cancel',
            onClick: closeBetModal,
            style: {
              flex: 1,
              padding: '12px',
              backgroundColor: isDarkMode ? '#4b5563' : '#e5e7eb',
              color: isDarkMode ? '#f9fafb' : '#374151',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer'
            }
          }, 'Cancel'),
          React.createElement('button', {
            key: 'submit',
            onClick: submitBet,
            style: {
              flex: 1,
              padding: '12px',
              backgroundColor: activeBet.choice === 'yes' ? '#10b981' : '#ef4444',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer'
            }
          }, 'Place Bet')
        ])
      ])),

      // Packages modal
      showPackages && React.createElement('div', {
        key: 'packages-modal',
        className: 'modal-overlay',
        style: {
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        },
        onClick: (e) => {
          if (e.target === e.currentTarget) setShowPackages(false);
        }
      }, React.createElement('div', {
        style: {
          backgroundColor: isDarkMode ? '#1f2937' : '#ffffff',
          padding: '24px',
          borderRadius: '12px',
          maxWidth: '500px',
          width: '90%',
          maxHeight: '90vh',
          overflow: 'auto'
        }
      }, [
        React.createElement('h3', {
          key: 'packages-title',
          style: {
            margin: '0 0 16px 0',
            color: isDarkMode ? '#f9fafb' : '#1f2937'
          }
        }, 'Buy BetCoins'),
        
        React.createElement('div', {
          key: 'packages-list',
          style: {
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            marginBottom: '16px'
          }
        }, packages.map(pkg => 
          React.createElement('div', {
            key: pkg.id,
            style: {
              padding: '16px',
              border: isDarkMode ? '1px solid #4b5563' : '1px solid #d1d5db',
              borderRadius: '8px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }
          }, [
            React.createElement('div', {
              key: 'package-info'
            }, [
              React.createElement('h4', {
                key: 'package-name',
                style: {
                  margin: '0 0 4px 0',
                  color: isDarkMode ? '#f9fafb' : '#1f2937'
                }
              }, pkg.name),
              React.createElement('p', {
                key: 'package-desc',
                style: {
                  margin: '0 0 4px 0',
                  fontSize: '14px',
                  color: isDarkMode ? '#d1d5db' : '#4b5563'
                }
              }, pkg.description),
              React.createElement('p', {
                key: 'package-amount',
                style: {
                  margin: 0,
                  fontWeight: 'bold',
                  color: '#3b82f6'
                }
              }, `${pkg.betcoins_amount.toLocaleString()} BetCoins`)
            ]),
            React.createElement('button', {
              key: 'buy-button',
              style: {
                padding: '8px 16px',
                backgroundColor: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontWeight: 'bold'
              }
            }, pkg.formatted_price)
          ])
        )),

        React.createElement('button', {
          key: 'close-packages',
          onClick: () => setShowPackages(false),
          style: {
            width: '100%',
            padding: '12px',
            backgroundColor: isDarkMode ? '#4b5563' : '#e5e7eb',
            color: isDarkMode ? '#f9fafb' : '#374151',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer'
          }
        }, 'Close')
      ])),

      // Notice
      notice && React.createElement('div', {
        key: 'notice',
        style: {
          position: 'fixed',
          top: '20px',
          right: '20px',
          padding: '12px 16px',
          backgroundColor: notice.type === 'error' ? '#dc2626' : 
                          notice.type === 'success' ? '#059669' : '#3b82f6',
          color: 'white',
          borderRadius: '6px',
          zIndex: 1001,
          maxWidth: '300px'
        }
      }, notice.message)
    ]);
  }

  // Mount the app
  const container = document.getElementById('dollarbets-predictions-app');
  if (container) {
    ReactDOM.render(React.createElement(PredictionApp), container);
  }
});

